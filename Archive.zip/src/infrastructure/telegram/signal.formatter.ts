import type { V5SignalEvent } from "../../strategy/v5/v5-wave.service";

/**
 * Sep 11 2026 (Karo), operator-requested Telegram presentation/design
 * cleanup -- FORMATTER-ONLY. No strategy logic, candle physics, P95
 * qualification, SL/TP, execution, or BTC_BLOCK computation is
 * touched anywhere in this file; every value below is read directly
 * from the SAME event data the previous formatter already used (plus
 * the new, purely-additive p95AtW1Qualification/maxIndividualEventUsdAtW1
 * fields, when available), simply displayed more compactly.
 */

function formatUsd(n: number | null | undefined): string {
  if (n === null || n === undefined) return "n/a";
  const abs = Math.abs(n);
  if (abs >= 1_000_000) return "$" + (n / 1_000_000).toFixed(2) + "M";
  if (abs >= 1_000)
    return (
      "$" +
      (n / 1_000).toFixed(abs >= 100_000 ? 0 : abs >= 10_000 ? 1 : 2) +
      "k"
    );
  return "$" + n.toFixed(0);
}

/** Sensible, generic symbol-price precision -- no per-symbol lookup
 *  table (that would be a design decision beyond "formatter only"):
 *  more decimals for smaller-magnitude prices, fewer for larger ones,
 *  trimming trailing zeros so e.g. 2515.637811928875 -> 2515.64 and
 *  0.204500 -> 0.2045. */
function formatPrice(n: number): string {
  const abs = Math.abs(n);
  const digits = abs >= 100 ? 2 : abs >= 1 ? 4 : 6;
  return Number(n.toFixed(digits)).toString();
}

function formatPct(n: number): string {
  return n.toFixed(2) + "%";
}

function formatDuration(ms: number): string {
  const totalMin = Math.round(ms / 60000);
  if (totalMin < 60) return totalMin + "m";
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  return m === 0 ? h + "h" : h + "h " + m + "m";
}

export function formatV5EntryMessage(
  event: V5SignalEvent,
  // Sep 12 2026 (Karo), operator-requested BTC_BLOCK redesign -- MAIN
  // Telegram shows this diagnostic line UNCONDITIONALLY for every ALT
  // signal (regardless of any user's own btcBlockEnabled), purely
  // hypothetical/research. Every other user's own Telegram (karo,
  // artak, ...) never shows it at all -- their own btcBlockEnabled
  // already controls real execution eligibility elsewhere; this line
  // is display-only. Default false so every existing call site other
  // than MAIN's own stays unaffected without needing to change.
  showBtcBlockDiagnostic: boolean = false,
): string {
  const time = new Date(event.signalTs).toISOString().slice(11, 19) + " UTC";
  const executed = event.plan !== null;
  const emoji = executed ? "🟢" : "🟡";

  const lines: string[] = [];
  lines.push(
    `${emoji} V5 ${executed ? "ENTRY" : "SIGNAL (not executed)"} ${event.symbol} ${event.side} · ${time}`,
  );
  lines.push("");

  if (event.plan) {
    const tpPct =
      (Math.abs(event.plan.tp - event.plan.entry) / event.plan.entry) * 100;
    const slPct =
      (Math.abs(event.plan.entry - event.plan.sl) / event.plan.entry) * 100;
    lines.push(`Entry: ${formatPrice(event.plan.entry)}`);
    lines.push(`SL: ${formatPrice(event.plan.sl)} (-${formatPct(slPct)})`);
    lines.push(`TP: ${formatPrice(event.plan.tp)} (+${formatPct(tpPct)})`);
    lines.push(`RR: ${event.plan.rr.toFixed(2)}`);

    const riskUsd = Number(process.env.V3_RISK_USD ?? 20);
    const slDistance = Math.abs(event.plan.entry - event.plan.sl);
    if (slDistance > 0) {
      const positionQty = riskUsd / slDistance;
      const notionalUsdt = positionQty * event.plan.entry;
      lines.push(`Risk: $${riskUsd} · Size: ${formatUsd(notionalUsdt)}`);
    }
  } else {
    lines.push(`Entry (reference only): ${formatPrice(event.entryPrice)}`);
    lines.push(`Plan rejected: ${event.rejectionReason ?? "unknown"}`);
  }

  lines.push("");
  lines.push(`SignalId: ${event.signalId}`);
  lines.push("");

  // Sep 11 2026 (Karo) -- prefer the REAL W1-qualification P95 when
  // available (p95AtW1Qualification, from the current candle-physics
  // engine), falling back to the older, generic p95AtQualification
  // snapshot only when the newer field is absent (the legacy,
  // non-cascade V5 path).
  const p95 = event.p95AtW1Qualification ?? event.p95AtQualification;
  lines.push(`P95: ${formatUsd(p95)}`);
  lines.push(`Episode: ${formatUsd(event.totalEpisodePressure)}`);
  lines.push("");

  for (const w of event.waveHistory) {
    const durationMs = w.extremeTs - w.anchorTs;
    lines.push(
      `W${w.waveNumber} · ${formatUsd(w.liqNotionalUsd)} · ${w.liqEvents} events · ${formatDuration(durationMs)}`,
    );
    const reclaimPart =
      w.reclaimPrice !== null
        ? ` · reclaim ${formatPrice(w.reclaimPrice)}`
        : "";
    lines.push(
      `    max ${formatUsd(w.maxSingleEventUsd)} · anchor ${formatPrice(w.anchorPrice)} → extreme ${formatPrice(w.extremePrice)}${reclaimPart}`,
    );
    lines.push("");
  }

  // Sep 12 2026 (Karo), operator-requested BTC_BLOCK redesign.
  //   - BTCUSDT's own signal: NEVER shows this line at all -- the
  //     diagnostic is only meaningful when comparing an ALT signal
  //     against BTC's own state; comparing BTC against itself is not.
  //   - Every ALT signal on MAIN (showBtcBlockDiagnostic=true): ALWAYS
  //     shown, based PURELY on the live BTC context vs this signal's
  //     own side -- never depends on any user's own btcBlockEnabled.
  //   - Every ALT signal on any other user's own Telegram
  //     (showBtcBlockDiagnostic=false, the default): never shown --
  //     that user's own btcBlockEnabled is an execution-eligibility
  //     setting, not a research-display feature.
  if (event.symbol !== "BTCUSDT" && showBtcBlockDiagnostic) {
    const cascadeSide = event.btcContext?.btcActiveCascadeSide ?? null;
    const wouldBlock =
      event.btcIntendedSideAtSignalTime !== null &&
      event.btcIntendedSideAtSignalTime === event.side;
    const suffix =
      cascadeSide !== null
        ? ` · BTC ${cascadeSide} cascade`
        : " · no serious BTC cascade";
    lines.push(
      `BTC_BLOCK would apply here: ${wouldBlock ? "YES" : "NO"}${suffix}`,
    );
  }

  return lines
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export function formatV5CloseMessage(
  symbol: string,
  side: string,
  // Sep 14 2026 (Karo), operator-reported bug fix -- "MANUAL" added.
  // Previously this parameter only accepted "TP"|"SL", so the
  // genuinely-ambiguous reconciliation case (Binance confirms the
  // position closed but could not determine which order fired) had
  // NO way to be represented honestly -- callers were forced to pass
  // a best-effort GUESS as if it were a confirmed TP/SL, paired with
  // a placeholder closePrice (the entry price itself), producing a
  // message that falsely claimed a confirmed TP or SL fill with a
  // fabricated 0.00% PnL. "MANUAL" is now a real, distinct outcome
  // that renders honestly instead of masquerading as TP or SL.
  outcome: "TP" | "SL" | "MANUAL",
  entry: number,
  closePrice: number,
  entryWaveNumber: number,
  timeframe?: "1m" | "3m" | "5m" | null,
  signalId?: string,
  durationMs?: number,
): string {
  void timeframe;
  if (outcome === "MANUAL") {
    // Sep 14 2026 (Karo) -- honest rendering for the ambiguous-reconciliation
    // case. closePrice is a PLACEHOLDER here (equals entry, by construction
    // in the caller) -- it is never a real fill, so it is never shown as
    // Exit/PnL, which would otherwise silently fabricate a 0.00% result.
    const lines = [`\u26a0\ufe0f V5 CLOSE ${symbol} ${side} · UNCONFIRMED`, ""];
    lines.push(`Entry: ${formatPrice(entry)}`);
    lines.push(
      `Position confirmed CLOSED on Binance, but the exact TP/SL fill could not be verified.`,
    );
    lines.push(
      `Exit price / PnL: NOT CONFIRMED -- please check this position on Binance directly.`,
    );
    lines.push(`Entered: W${entryWaveNumber}`);
    if (signalId) lines.push("", `SignalId: ${signalId}`);
    return lines
      .join("\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }
  const emoji = outcome === "TP" ? "✅" : "❌";
  const pnlPct =
    side === "LONG"
      ? (closePrice - entry) / entry
      : (entry - closePrice) / entry;

  const lines = [`${emoji} V5 CLOSE ${symbol} ${side} · ${outcome}`, ""];
  lines.push(`Entry: ${formatPrice(entry)}`);
  lines.push(`Exit: ${formatPrice(closePrice)}`);
  lines.push(`PnL: ${pnlPct >= 0 ? "+" : ""}${formatPct(pnlPct * 100)}`);
  if (durationMs !== undefined)
    lines.push(`Duration: ${formatDuration(durationMs)}`);
  lines.push(`Entered: W${entryWaveNumber}`);
  if (signalId) {
    lines.push("");
    lines.push(`SignalId: ${signalId}`);
  }
  return lines.join("\n");
}
