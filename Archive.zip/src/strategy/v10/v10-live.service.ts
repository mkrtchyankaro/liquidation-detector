import { childLogger } from "../../infrastructure/logging/logger";
import { mongoMinBarLoader, type MinBarLoader } from "../shared/minute-loader";
import { getSymbolFilters, roundToStep, runEntrySequence } from "../../execution/entry-sequence";
import { ourIds, positionAmt, recoverEntry, settle, symbolClear, type SettleRest } from "../../execution/real-settle";
import { strategyClientOrderId } from "../../execution/client-order-id";
import { withSymbolLock } from "../../execution/other-trades";
import { simTrade } from "../lib/sltp";
import type { MinBar } from "../lib/dc15";
import { estimateFeesUsd } from "../shared/fees";
import { BTC, NEW_COIN_DAYS, rulesFor, type V10Settings } from "./v10-config";
import { againstCandles, btcRank1At, givebackPct, lastCandleEnd, levels, moveOf, ownMove, pickAlts, rank1At, V10_CANDLE_MS, V10_HISTORY_MS, type V10Pick, type V10Turn } from "./v10-engine";
import type { V10SignalDoc, V10Store, V10TradeDoc } from "./v10-repository";
import { formatV10Close, formatV10Entry, formatV10Failure, formatWallEntry, v10Head } from "./v10-telegram";
import { hourCandle, wallsAt, WallTracker, type WallSignal } from "./wall-engine";
import type { WallSource } from "./wall-data";
import { bookView as makeBookView, type V10BookSource, type V10BookView } from "./v10-book";
import { zoneWall, type V10ZoneSource, type V10ZoneView } from "./v10-zone";

const log = childLogger({ mod: "v10-live" });

/**
 * V10 LIVE -- BTC-led alts (Johnny, Oct 2 2026). Completely separate from V11: own settings ("v10"), own collections,
 * own messages. Uses the minute_bars the bot already writes (price + OI + liquidations, 1 row per symbol per minute).
 *
 *  every minute at hh:mm:45
 *    1. once per closed 15m candle (from 90 s after its close, at most 10 min late):
 *       part 1 "V10 · BTC": BTC's turn at that close (src/strategy/v10/v10-engine.ts = the research code). RANK 1 ->
 *         the picks -> one trade per (pick, user), if that user takes part 1 and this side.
 *       part 2 "V10 · ALT" (only while some user has it on): each alt's OWN turn at that close, RANK 1, moved on its own
 *         -> one trade per user on that alt. Only alts with as much history as BTC (new coins wait). Part 1 runs first,
 *         so it has the priority on a coin.
 *       Each signal is handled once (unique signalId in v10_signals, across restarts).
 *    2. PAPER trades: SL / TP on the minute high / low (SL first on a same-minute tie)
 *    3. (Oct 7) part 3 "V10 · WALL", once per closed 1h candle (from 90 s after it, at most 10 min late), every coin of
 *       wallSymbols: src/strategy/v10/wall-engine.ts = the research test's code. A coin is watched only after 2 days of
 *       our liquidations and only while the minute data is fresh. SL = the wall's far edge (a fixed price), TP = wallTpPct
 *       % from the signal price, both the SAME for PAPER and REAL; still open after wallTimeoutHours -> closed at market.
 *  every 15 s
 *    REAL trades: Binance position flat? -> cancel our leftovers -> exact close from Binance fills
 *
 * REAL entries reuse the shared entry sequence (market entry -> SL verified, else fail-safe close -> TP). The SL / TP are
 * the SAME prices as PAPER (the configured % from the signal price); the size is set at the executable price so the $
 * risk stays riskUsd; a price already at / beyond the SL or TP -> not opened. Before a REAL entry the symbol must be
 * completely clear on that account (no position, no order, no stop) and the user must not have a REAL V11 trade open on
 * it (Oct 12: V9 was removed; the check used to be against V9). An entry that did not finish (crash, an error after the order may have been sent) is recovered by the 15 s
 * monitor: our SL resting -> the trade is adopted; no SL -> the position is closed at market. Never unprotected.
 * Users are independent: one user's failure never affects another.
 */
export interface V10UserRef {
  userId: string;
  /** OFF users are listed too (when they have Binance keys) so their earlier REAL trades are still watched */
  mode: "OFF" | "PAPER" | "REAL";
  riskUsd: number;
  /** REAL entries -- only for mode REAL */
  binanceRest: SettleRest | null;
  /** watching existing REAL trades -- whatever the mode now (a user switched to PAPER / OFF keeps being watched) */
  monitorRest?: SettleRest | null;
  leverage?: number;
  marginMode?: "ISOLATED" | "CROSSED";
  telegram: { sendMessage(text: string): Promise<unknown> } | null;
}

export type V10BarLoader = MinBarLoader;

/** the minute bars of our database (moved to ../shared/minute-loader.ts on Oct 12, unchanged) */
export const mongoV10Loader = mongoMinBarLoader;

const M = 60_000;
const RUN_OFFSET_MS = 45_000;
const READY_MS = 90_000;        // the candle's last minute bar is written ~20 s after that minute
const STALE_MS = 10 * M;        // never act on a signal more than 10 min after its candle closed
const REAL_MONITOR_MS = 15_000;
const STUCK_ENTRY_MS = 5 * M;
const MAX_CLOSE_REPORT_ATTEMPTS = 8;
const ALT_LEAD_MS = 10 * M;
const ALT_WAIT_MS = 5 * M;
const FAILSAFE_NOTE = "entry without its SL -- closed at market";
const BOOK_LATE_MS = 4 * M;      // a snapshot taken later than this after the close is not "at the close"
const H = 60 * M;
/** WALL: the touch memory is rebuilt from this many hours back after a restart */
const WALL_WARMUP_H = 72;
/** WALL: a coin is traded only after this much of our liquidation data (the walls are built from it) */
const WALL_MIN_LIQ_MS = 2 * 24 * H;
const RETRY_ALERT = 20;          // x 15 s = 5 min      // wait up to 5 min after the close for every alt's last minute     // alts' bars from a little before BTC's move start (priceAt looks back up to 6 min)

export class V10LiveService {
  private minuteTimer: NodeJS.Timeout | null = null;
  private monitorTimer: NodeJS.Timeout | null = null;
  private minuteBusy = false;
  private monitorBusy = false;
  private handled = new Set<number>();
  /** part 2: `${candleEnd}:${symbol}` already decided */
  private handledOwn = new Set<string>();
  /** REAL entries running right now -- the 15 s monitor never touches them */
  private entering = new Set<string>();
  private indexesReady = false;
  /** 15m closes whose order book snapshot is stored */
  private bookDone = new Set<number>();
  /** WALL: hour ends fully decided, `${hourEnd}:${symbol}` decided, and each coin's touch memory */
  private wallDone = new Set<number>();
  private wallDoneSym = new Set<string>();
  private wallState = new Map<string, { tracker: WallTracker; lastHs: number; blocked: boolean }>();
  /** WALL: a signal found but not stored yet (the database failed) -> retried every minute until stale */
  private wallPending = new Map<string, WallSignal>();

  constructor(
    private readonly settings: V10Settings,
    private readonly users: () => V10UserRef[],
    private readonly load: V10BarLoader,
    private readonly store: V10Store,
    private readonly now: () => number = Date.now,
    /** Oct 4: the order book at every 15m close -- recorded and shown in the entry message, never changes a trade */
    private readonly book: V10BookSource | null = null,
    /** Oct 4: the 4h zone at the signal -- shown in the entry message and kept on the row, never changes a trade */
    private readonly zone: V10ZoneSource | null = null,
    /** Oct 7: part 3 WALL -- Binance klines + our liquidations (null = WALL never runs) */
    private readonly wallSource: WallSource | null = null,
  ) {}

  private async ensureIndexes(): Promise<boolean> {
    if (this.indexesReady) return true;
    try { await this.store.ensureIndexes(); this.indexesReady = true; }
    catch (err) { log.error({ err: err instanceof Error ? err.message : String(err) }, "[V10_INDEXES_FAILED] -- no new signals until they exist, retried every minute"); }
    return this.indexesReady;
  }

  async start(): Promise<void> {
    await this.ensureIndexes();
    const s = this.settings;
    if (!s.enabled) log.warn(`[V10_MONITOR_ONLY] v10 is disabled -- no new signals; open REAL V10 trades are still watched (users: ${this.users().map((u) => u.userId).join(",") || "none"})`);
    log.warn(`[V10_READY] entry=${s.rule.entry} ownEntry=${s.ownRule.entry} ownLongEntry=${s.ownLongRule.entry} ownR2=${s.ownR2Minutes}m short=${s.short} long=${s.long} sl=${s.slPct}% tp=${s.tpPct}% picks=${s.picks} rank=${s.rankWindowHours}h alts=${s.symbols.length} users=${this.users().map((u) => {
      const r = rulesFor(s, u.userId);
      return `${u.userId}:${u.mode}(${[r.short ? "S" : "", r.long ? "L" : ""].join("") || "none"},btc:${r.btc ? `sl${r.slPct}/tp${r.tpPct}` : "off"},alt:${r.own ? `sl${r.ownSlPct}/tp${r.ownTpPct}${r.ownLong ? "+L" : ""}` : "off"}${r.maxOpen ? `,max${r.maxOpen}` : ""})`;
    }).join(" ") || "(none)"}`);
    log.warn(`[V10_WALL_READY] wall=${s.wall} tp=${s.wallTpPct}% room>=${s.wallRoomRatio}x maxStop=${s.wallMaxStopPct ?? "off"} timeout=${s.wallTimeoutHours !== null ? `${s.wallTimeoutHours}h` : "none"} rebuild=${s.wallRebuildHours ?? "off"} coins=${s.wallSymbols.length} source=${this.wallSource ? "yes" : "NONE"} users=${this.users().map((u) => {
      const r = rulesFor(s, u.userId);
      return `${u.userId}:${u.mode}(${r.wall ? `on,$${r.wallRiskUsd ?? u.riskUsd}${r.wallMaxOpen ? `,max${r.wallMaxOpen}` : ""}` : "off"})`;
    }).join(" ") || "(none)"}`);
    const tick = (): void => {
      const now = this.now();
      const next = Math.floor(now / M) * M + M + RUN_OFFSET_MS;
      this.minuteTimer = setTimeout(() => { void this.onMinute().finally(tick); }, Math.max(1_000, next - now));
    };
    tick();
    this.monitorTimer = setInterval(() => void this.monitorReal(), REAL_MONITOR_MS);
  }

  stop(): void {
    if (this.minuteTimer) clearTimeout(this.minuteTimer);
    if (this.monitorTimer) clearInterval(this.monitorTimer);
    this.minuteTimer = this.monitorTimer = null;
  }

  /** One round (public for tests). Signal and PAPER exits are isolated from each other. */
  async onMinute(): Promise<void> {
    if (this.minuteBusy) return;
    this.minuteBusy = true;
    try {
      try { if (this.settings.enabled && this.book) await this.recordBook(); }
      catch (err) { log.error({ err: err instanceof Error ? err.message : String(err) }, "[V10_BOOK_FAILED] -- retried next minute, trading unaffected"); }
      try { if (this.settings.enabled && await this.ensureIndexes()) await this.checkSignal(); }
      catch (err) { log.error({ err: err instanceof Error ? err.message : String(err) }, "[V10_SIGNAL_FAILED] -- retried next minute, the other strategies unaffected"); }
      try { if (this.settings.enabled && this.wallSource && await this.ensureIndexes()) await this.checkWallSignals(); }
      catch (err) { log.error({ err: err instanceof Error ? err.message : String(err) }, "[V10_WALL_SIGNAL_FAILED] -- retried next minute"); }
      try { await this.monitorPaper(); }
      catch (err) { log.error({ err: err instanceof Error ? err.message : String(err) }, "[V10_PAPER_MONITOR_FAILED] -- retried next minute"); }
    } finally {
      this.minuteBusy = false;
    }
  }

  // ── 0. order book snapshot at the 15m close (before the signal, which waits 90 s) ──
  private async recordBook(): Promise<void> {
    const now = this.now(), end = lastCandleEnd(now);
    if (!this.book || this.bookDone.has(end) || now - end > BOOK_LATE_MS) return;
    const n = await this.book.record(end, this.settings.symbols);
    if (n === 0 && this.settings.symbols.length) { log.warn({ candleEnd: new Date(end).toISOString() }, "[V10_BOOK_NONE] -- retried next minute"); return; }
    this.bookDone.add(end);
    if (this.bookDone.size > 50) this.bookDone = new Set([...this.bookDone].slice(-20));
    log.info({ candleEnd: new Date(end).toISOString(), stored: n, of: this.settings.symbols.length }, "[V10_BOOK]");
  }

  /** the book at the top (bottom) candle's close and at the entry candle's close; null when unknown -- never throws */
  private async bookFor(sig: V10SignalDoc, symbol: string): Promise<V10BookView | null> {
    if (!this.book) return null;
    try {
      const topEnd = sig.turn.extremeT + V10_CANDLE_MS, nowEnd = sig.turn.candleEnd;
      const vol = this.book.avgVol15 ? this.book.avgVol15(symbol, nowEnd).catch(() => null) : Promise.resolve(null);
      const [top, now, vol15] = await Promise.all([topEnd < nowEnd ? this.book.get(symbol, topEnd) : Promise.resolve(null), this.book.get(symbol, nowEnd), vol]);
      return makeBookView(sig.side, topEnd, nowEnd, top, now, vol15);
    } catch (err) {
      log.warn({ symbol, err: err instanceof Error ? err.message : String(err) }, "[V10_BOOK_READ_FAILED] -- the message goes without it");
      return null;
    }
  }

  /** the coin's 4h zone known at the signal; null when unknown -- never throws */
  private async zoneFor(sig: V10SignalDoc, p: V10Pick): Promise<V10ZoneView | null | undefined> {
    if (!this.zone) return undefined;
    try { return await this.zone.at(p.symbol, sig.turn.candleEnd, p.price); }
    catch (err) {
      log.warn({ symbol: p.symbol, err: err instanceof Error ? err.message : String(err) }, "[V10_ZONE_FAILED] -- the message goes without it");
      return undefined;
    }
  }

  // ── 1. signal ────────────────────────────────────────────────────────────────────────────────────────────────
  private async checkSignal(): Promise<void> {
    const now = this.now(), end = lastCandleEnd(now);
    if (now - end < READY_MS || now - end > STALE_MS) return;
    const ownOn = this.users().some((u) => u.mode !== "OFF" && rulesFor(this.settings, u.userId).own);
    if (this.handled.has(end) && !ownOn) return;
    const btc = await this.load(BTC, end - V10_HISTORY_MS, end);
    const last = btc[btc.length - 1];
    if (!last || last.t < end - M) {
      // the candle's last minute is not written yet -> try again next minute (until stale)
      log.warn({ candleEnd: new Date(end).toISOString(), lastBar: last ? new Date(last.t).toISOString() : null }, "[V10_BTC_DATA_NOT_READY]");
      return;
    }
    // Oct 4: the BTC-led part runs only while some user takes it ("btc": false everywhere -> not even computed)
    const btcOn = this.users().some((u) => u.mode !== "OFF" && rulesFor(this.settings, u.userId).btc);
    if (!btcOn) this.handled.add(end);
    const btcDone = this.handled.has(end) || await this.checkBtcSignal(end, now, btc);
    // part 2 only after part 1 decided this candle (part 1 has the priority on a coin)
    if (btcDone && ownOn) await this.checkOwnSignals(end, now, btc);
  }

  /** part 1 -- true when this candle is decided (signal handled or none), false = wait for data (retried next minute) */
  private async checkBtcSignal(end: number, now: number, btc: MinBar[]): Promise<boolean> {
    const done = (): boolean => {
      this.handled.add(end);
      if (this.handled.size > 200) this.handled = new Set([...this.handled].slice(-100));
      return true;
    };
    const turn = btcRank1At(btc, end, this.settings.rankWindowHours, this.settings.rule);
    if (!turn) return done();
    const closes = new Map<string, Map<number, number>>();
    const late: string[] = [];
    for (const s of this.settings.symbols) {
      try {
        const bars = await this.load(s, turn.moveStartT - ALT_LEAD_MS, end);
        // late = had data in the last hour but not the candle's last minute yet (a coin without any recent data is not waited for)
        if (bars.length && bars[bars.length - 1].t < end - M && bars[bars.length - 1].t >= end - 60 * M) late.push(s);
        if (bars.length) closes.set(s, new Map(bars.map((b) => [b.t, b.close])));
      } catch (err) {
        late.push(s);
        log.error({ symbol: s, err: err instanceof Error ? err.message : String(err) }, "[V10_ALT_LOAD_FAILED]");
      }
    }
    // every alt's last minute should be there (the entry price is that minute's close); wait for it a little
    if (late.length && now - end < ALT_WAIT_MS) {
      log.warn({ candleEnd: new Date(end).toISOString(), late }, "[V10_ALT_DATA_NOT_READY] -- retried next minute");
      return false;
    }
    if (late.length) log.warn({ late }, "[V10_ALT_DATA_LATE] -- proceeding; these alts use their last known price or are left out");
    const picks = pickAlts(turn, new Map(btc.map((b) => [b.t, b.close])), closes, this.settings.picks);
    const signalId = `v10-${new Date(end).toISOString().slice(0, 16)}-${turn.side}`;
    const sig: V10SignalDoc = { signalId, kind: "BTC", side: turn.side, symbol: BTC, turn, picks, rankWindowHours: this.settings.rankWindowHours, createdAt: new Date(now) };
    const fresh = await this.store.insertSignal(sig); // throws on a DB error -> not marked done, retried next minute
    done();
    if (!fresh) return true; // already handled (restart)
    log.warn({ signalId, side: turn.side, picks: picks.map((p) => `${p.symbol} x${p.x.toFixed(2)}`) }, "[V10_SIGNAL]");
    await this.openForAll(sig);
    return true;
  }

  /** part 2 -- each alt's own RANK 1 turn at this close, if it moved on its own. Each (candle, alt) decided once. */
  private async checkOwnSignals(end: number, now: number, btc: MinBar[]): Promise<void> {
    const btcCloses = new Map(btc.map((b) => [b.t, b.close]));
    for (const s of this.settings.symbols) {
      const key = `${end}:${s}`;
      if (this.handledOwn.has(key)) continue;
      try {
        const bars = await this.load(s, end - V10_HISTORY_MS, end);
        if (!bars.length) { this.handledOwn.add(key); continue; }
        // Oct 4: a coin with less than NEW_COIN_DAYS of our data is "new" -- its signals are made too, each user decides
        // (newShort / newLong; before: new coins were never part 2)
        const newCoin = bars[0].t > end - NEW_COIN_DAYS * 24 * 60 * M + 60 * M;
        const last = bars[bars.length - 1];
        // the alt's last minute not written yet (but it had data in the last hour) -> retried next minute, a little
        if (last && last.t < end - M && last.t >= end - 60 * M && now - end < ALT_WAIT_MS) continue;
        this.handledOwn.add(key);
        if (this.handledOwn.size > 5000) this.handledOwn = new Set([...this.handledOwn].slice(-2500));
        // Oct 4: SHORTs by ownRule, LONGs by ownLongRule ("flush" by default); each side decided on its own
        const turns = [rank1At(bars, end, this.settings.rankWindowHours, this.settings.ownRule, "SHORT"), rank1At(bars, end, this.settings.rankWindowHours, this.settings.ownLongRule, "LONG")];
        for (const turn of turns) {
          if (!turn) continue;
          const own = ownMove(turn, new Map(bars.map((b) => [b.t, b.close])), btcCloses, this.settings.ownR2Minutes);
          if (!own) { log.info({ symbol: s, side: turn.side, candleEnd: new Date(end).toISOString() }, "[V10_ALT_TURN_WITH_BTC] -- not a part-2 signal"); continue; }
          const signalId = `v10alt-${new Date(end).toISOString().slice(0, 16)}-${s.replace(/USDT$/, "")}-${turn.side}`;
          const pick: V10Pick = { symbol: s, rank: 1, x: own.btcPct !== 0 ? own.coinPct / own.btcPct : NaN, follow: own.follow, coinPct: own.coinPct, btcPct: own.btcPct, price: turn.price };
          const against = againstCandles(bars, turn);
          const sig: V10SignalDoc = { signalId, kind: "OWN", side: turn.side, symbol: s, turn, own, picks: [pick], rankWindowHours: this.settings.rankWindowHours, createdAt: new Date(now), against, ...(newCoin ? { newCoin: true } : {}) };
          if (!(await this.store.insertSignal(sig))) continue;
          log.warn({ signalId, side: turn.side, entry: turn.entry, how: own.how, follow: own.follow }, "[V10_ALT_SIGNAL]");
          await this.openForAll(sig);
        }
      } catch (err) {
        this.handledOwn.delete(key); // retried next minute (until the candle is stale)
        log.error({ symbol: s, err: err instanceof Error ? err.message : String(err) }, "[V10_ALT_SIGNAL_FAILED] -- this alt retried next minute");
      }
    }
  }

  // ── 1b. part 3 WALL (Oct 7) ──────────────────────────────────────────────────────────────────────────────────
  /** once per closed 1h candle: every coin's walls and the 1h rule (wall-engine.ts = the research test's code) */
  private async checkWallSignals(): Promise<void> {
    const s = this.settings, now = this.now(), end = Math.floor(now / H) * H;
    if (now - end < READY_MS || now - end > STALE_MS || this.wallDone.has(end)) return;
    const done = (): void => {
      this.wallDone.add(end);
      if (this.wallDone.size > 100) this.wallDone = new Set([...this.wallDone].slice(-50));
      if (this.wallDoneSym.size > 5000) this.wallDoneSym = new Set([...this.wallDoneSym].slice(-2500));
    };
    if (!this.wallSource || !this.users().some((u) => u.mode !== "OFF" && rulesFor(s, u.userId).wall)) return done();
    const params = { kind: "WICK" as const, tpPct: s.wallTpPct, roomRatio: s.wallRoomRatio, maxStopPct: s.wallMaxStopPct ?? Infinity, ...(s.wallRebuildHours !== null ? { rebuildHours: s.wallRebuildHours } : {}) };
    const openWall = (await this.store.findOpenTrades()).filter((t) => t.kind === "WALL");
    let pending = 0;
    for (const sym of s.wallSymbols) {
      const key = `${end}:${sym}`;
      if (this.wallDoneSym.has(key)) continue;
      const waiting = this.wallPending.get(key);
      if (waiting) {
        try { await this.openWallSignal(sym, waiting, now); this.wallPending.delete(key); this.wallDoneSym.add(key); }
        catch (err) { pending++; log.error({ symbol: sym, err: err instanceof Error ? err.message : String(err) }, "[V10_WALL_SIGNAL_STORE_FAILED] -- retried next minute"); }
        continue;
      }
      try {
        // our minute data must be fresh: the collector that writes it also writes the liquidations the walls are made of
        const bars = await this.load(sym, end - 10 * M, end);
        const last = bars[bars.length - 1];
        if (!last || last.t < end - 2 * M) {
          if (now - end < ALT_WAIT_MS) { pending++; continue; }
          log.warn({ symbol: sym, hourEnd: new Date(end).toISOString(), lastBar: last ? new Date(last.t).toISOString() : null }, "[V10_WALL_DATA_STALE] -- no WALL decision for this coin this hour");
          this.wallDoneSym.add(key);
          continue;
        }
        const data = await this.wallSource.data(sym, now);
        // the walls are built from our liquidations: a coin with less than 2 days of them is not traded yet (as tested)
        if (data.firstLiqT === null || end - data.firstLiqT < WALL_MIN_LIQ_MS) { this.wallDoneSym.add(key); continue; }
        // the hour's four 15m candles must all be there
        if (!hourCandle(data.q15, end - H)) {
          if (now - end < ALT_WAIT_MS) { pending++; continue; }
          log.warn({ symbol: sym, hourEnd: new Date(end).toISOString() }, "[V10_WALL_CANDLE_MISSING] -- no WALL decision for this coin this hour");
          this.wallDoneSym.add(key);
          continue;
        }
        let st = this.wallState.get(sym);
        if (!st) { st = { tracker: new WallTracker(), lastHs: end - (WALL_WARMUP_H + 1) * H, blocked: false }; this.wallState.set(sym, st); }
        // a WALL trade open on the coin -> the coin waits (as in the test); after it, the touch memory starts fresh
        const blocked = openWall.some((t) => t.symbol === sym);
        let sig: WallSignal | null = null;
        for (let hs = st.lastHs + H; hs <= end - H; hs += H) {
          st.lastHs = hs;
          if (blocked) { st.blocked = true; continue; }
          if (st.blocked) { st.tracker.reset(); st.blocked = false; }
          const c = hourCandle(data.q15, hs);
          if (!c) continue;
          const step = st.tracker.step(c, wallsAt(data, hs, st.tracker.minFieldStart), params);
          const current = hs === end - H;
          if (current && step.broken) log.warn({ symbol: sym, way: step.broken, hour: new Date(hs).toISOString() }, `[V10_WALL_BROKEN] -- the walls are void, new walls from now on, no signal for ${s.wallRebuildHours}h`);
          if (current) for (const k of step.skips) log.info({ symbol: sym, side: k.side, why: k.why, detail: k.detail }, "[V10_WALL_SKIP]");
          // a signal of an EARLIER hour (catching up after a restart) is never traded -- it only ends that touch
          if (step.signal) { if (current) sig = step.signal; else st.tracker.reset(); }
        }
        if (sig) {
          st.tracker.reset();
          // the touch memory has moved on: if storing the signal fails, the SIGNAL is kept and retried, never lost
          this.wallPending.set(key, sig);
          await this.openWallSignal(sym, sig, now);
          this.wallPending.delete(key);
        }
        this.wallDoneSym.add(key);
      } catch (err) {
        pending++;
        log.error({ symbol: sym, err: err instanceof Error ? err.message : String(err) }, "[V10_WALL_COIN_FAILED] -- this coin retried next minute");
      }
    }
    if (pending === 0) done();
    if (now - end >= STALE_MS - M) for (const k of this.wallPending.keys()) if (k.startsWith(`${end}:`)) {
      log.error({ key: k }, "[V10_WALL_SIGNAL_LOST] -- could not be stored before it became stale");
      this.wallPending.delete(k);
    }
  }

  private async openWallSignal(symbol: string, w: WallSignal, now: number): Promise<void> {
    const signalId = `v10wall-${new Date(w.candleEnd).toISOString().slice(0, 16)}-${symbol.replace(/USDT$/, "")}-${w.side}`;
    const turn: V10Turn = { candleEnd: w.candleEnd, side: w.side, price: w.entry, candleOiPct: 0, label: "WALL", moveStartT: w.touchedAt, peakT: w.hs, moveOiPct: 0, extreme: w.entry, extremeT: w.hs, movePct: 0, fromPeakOiPct: 0, prior: 0 };
    const pick: V10Pick = { symbol, rank: 1, x: 0, follow: 0, coinPct: 0, btcPct: 0, price: w.entry };
    const sig: V10SignalDoc = { signalId, kind: "WALL", side: w.side, symbol, turn, picks: [pick], rankWindowHours: 0, createdAt: new Date(now), wall: w };
    if (!(await this.store.insertSignal(sig))) return; // already handled (restart)
    log.warn({ signalId, side: w.side, entry: w.entry, sl: w.stop, tp: w.tp, lower: w.walls.lower, upper: w.walls.upper }, "[V10_WALL_SIGNAL]");
    await Promise.all(this.users().map((u) => this.openWallTrade(u, sig, w).catch((err) =>
      log.error({ userId: u.userId, signalId, symbol, err: err instanceof Error ? err.message : String(err) }, "[V10_WALL_OPEN_UNEXPECTED] -- isolated"))));
  }

  private async openWallTrade(u: V10UserRef, sig: V10SignalDoc, w: WallSignal): Promise<void> {
    if (u.mode === "OFF") return;
    const r = rulesFor(this.settings, u.userId);
    if (!r.wall) return;
    const riskUsd = r.wallRiskUsd ?? u.riskUsd;
    const orderSignalId = `${sig.signalId}:${sig.symbol}`;
    const base: V10TradeDoc = {
      tradeId: `${orderSignalId}:${u.userId}`, orderSignalId, signalId: sig.signalId, kind: "WALL", userId: u.userId, mode: u.mode,
      symbol: sig.symbol, side: w.side, pick: { rank: 1, x: 0, follow: 0, coinPct: 0, btcPct: 0 },
      state: "OPEN", createdAt: w.candleEnd, entryPrice: null, slPrice: w.stop, tpPrice: null, slPct: w.riskPct, tpPct: this.settings.wallTpPct,
      quantity: null, plannedRiskUsd: riskUsd, actualRiskUsd: null, binance: null,
      closedAt: null, exitPrice: null, pnlUsd: null, pnlR: null, feesUsd: null, closeReason: null, failureReason: null, closeAttempts: 0, entryInProgress: true, entryStartedAt: null,
      wall: w, ...(this.settings.wallTimeoutHours !== null ? { timeoutAt: w.candleEnd + this.settings.wallTimeoutHours * H } : {}),
    };
    const skip = async (reason: string, tell: boolean, state: "SKIPPED" | "FAILED" = "SKIPPED"): Promise<void> => {
      const t = { ...base, state, failureReason: reason, entryInProgress: false };
      if (!(await this.store.insertTrade(t))) await this.store.updateTrade(base.tradeId, { state, failureReason: reason, entryInProgress: false });
      log.warn({ userId: u.userId, tradeId: base.tradeId, reason }, `[V10_TRADE_${state}]`);
      if (tell) await this.notify(u, formatV10Failure(t));
    };
    const open = await this.store.findOpenTrades();
    // one trade per coin per user, whatever the part or the side (a REAL account in one-way mode never holds both)
    if (open.some((t) => t.userId === u.userId && t.symbol === sig.symbol)) return skip(`a V10 trade on ${sig.symbol} is already open for this user`, false);
    if (r.wallMaxOpen !== null) {
      const mine = open.filter((t) => t.userId === u.userId && t.kind === "WALL");
      if (mine.length >= r.wallMaxOpen) return skip(`MAX_OPEN: ${mine.length} WALL trades already open (${mine.map((t) => `${t.symbol} ${t.side}`).join(", ")}), limit ${r.wallMaxOpen}`, true);
    }
    const short = w.side === "SHORT";
    if (!(w.entry > 0) || !(Math.abs(w.entry - w.stop) > 0) || (short ? !(w.stop > w.entry && w.tp < w.entry) : !(w.stop < w.entry && w.tp > w.entry)))
      return skip(`bad levels: entry ${w.entry}, SL ${w.stop}, TP ${w.tp}`, true, "FAILED");

    if (u.mode === "PAPER") {
      const t: V10TradeDoc = { ...base, entryPrice: w.entry, slPrice: w.stop, tpPrice: w.tp, quantity: riskUsd / Math.abs(w.entry - w.stop), actualRiskUsd: riskUsd, entryInProgress: false };
      if (!(await this.store.insertTrade(t))) return;
      log.warn({ tradeId: t.tradeId, entry: w.entry, sl: w.stop, tp: w.tp }, "[V10_WALL_PAPER_ENTRY]");
      await this.notify(u, formatWallEntry(sig, t));
      return;
    }

    // REAL -- the same safety as the other parts: fresh signal, no V11 trade, the symbol completely clear on the account,
    // the SL / TP are the signal's prices (the SL = the wall's far edge); a price already at / beyond them -> not opened
    const rest = u.binanceRest;
    if (u.mode !== "REAL" || !rest) return;
    if (this.now() - w.candleEnd > STALE_MS) return skip("signal too old for a market entry", true);
    // Oct 12: the checks and our OPEN row under one lock per (user, symbol) -- V11 runs in the same process
    const prep = await withSymbolLock(u.userId, sig.symbol, async (): Promise<{ row: V10TradeDoc; exec: number } | null> => {
      if (await this.store.hasOpenOtherTrade(u.userId, sig.symbol)) { await skip(`a REAL V11 trade on ${sig.symbol} is open for this user -- V10 never trades on top of it`, true); return null; }
      const busy = await symbolClear(rest, sig.symbol);
      if (busy) { await skip(`${busy} -- V10 never trades on top of it`, true); return null; }
      const book = (await rest.getBookTicker?.(sig.symbol).catch(() => null)) as { bidPrice?: string; askPrice?: string } | null;
      const exec = Number(short ? book?.bidPrice : book?.askPrice);
      if (!(exec > 0)) { await skip("no executable price from Binance", true); return null; }
      if (short ? exec >= w.stop : exec <= w.stop) { await skip(`the price already reached the SL: now ${exec}, signal ${w.entry}, SL ${+w.stop.toPrecision(8)} -- the signal is over`, true); return null; }
      if (short ? exec <= w.tp : exec >= w.tp) { await skip(`the price already reached the TP: now ${exec}, signal ${w.entry}, TP ${+w.tp.toPrecision(8)} -- too late`, true); return null; }
      const row: V10TradeDoc = { ...base, entryStartedAt: this.now() };
      if (!(await this.store.insertTrade(row))) return null;
      this.entering.add(row.tradeId);
      return { row, exec };
    });
    if (!prep) return;
    const { row, exec } = prep;
    try {
      const out = await runEntrySequence(rest, {
        userId: u.userId, globalSignalId: orderSignalId, symbol: sig.symbol, side: w.side,
        quantity: riskUsd / Math.abs(exec - w.stop), entryPriceEstimate: exec,
        slPrice: w.stop, initialTpPrice: w.tp,
        riskUsd, leverage: u.leverage, marginMode: u.marginMode,
      });
      if (out.outcome === "ENTRY_FAILED" || out.outcome === "PROTECTION_FAILED_CLOSED") {
        await this.store.updateTrade(row.tradeId, { failureReason: out.reason });
        log.error({ tradeId: row.tradeId, reason: out.reason, outcome: out.outcome }, "[V10_ENTRY_NOT_CONFIRMED] -- handed to the recovery");
        return;
      }
      const binance: V10TradeDoc["binance"] = {
        entryClientOrderId: out.entryClientOrderId, slAlgoId: out.slBinanceAlgoId, slClientAlgoId: out.slClientAlgoId,
        ...(out.outcome === "ENTRY_ACTIVE_WITH_TP" ? { tpOrderId: out.tpBinanceOrderId, tpClientOrderId: out.tpClientOrderId } : { tpFailureReason: out.tpFailureReason }),
      };
      const fields: Partial<V10TradeDoc> = { entryPrice: out.entryPrice, quantity: out.quantity, tpPrice: out.tpPrice ?? null, actualRiskUsd: out.actualRiskUsd ?? null, binance, entryInProgress: false };
      await this.store.updateTrade(row.tradeId, fields);
      log.warn({ tradeId: row.tradeId, ...fields }, "[V10_WALL_REAL_ENTRY]");
      await this.notify(u, formatWallEntry(sig, { ...row, ...fields } as V10TradeDoc));
    } finally {
      this.entering.delete(row.tradeId);
    }
  }

  /** WALL (REAL): still open after wallTimeoutHours -> a reduce-only MARKET close of what is left of OUR position.
   *  Our close orders have deterministic client ids (MARKET_EXIT revision 0, 1, ...): after a crash they are found, never
   *  sent twice; a close that filled nothing (expired / cancelled) is followed by the next revision. timeoutSentAt is set
   *  only once one of OUR close orders really filled (it makes the close report say TIMEOUT). Runs every cycle after the
   *  time-out until Binance shows the position gone; the normal settle then cancels our SL / TP and reports the close.
   *  false = do not settle this cycle (retried next cycle). */
  private async timeoutClose(t: V10TradeDoc, u: V10UserRef, rest: SettleRest): Promise<boolean> {
    const ids = [0, 1, 2, 3, 4].map((r) => strategyClientOrderId(t.userId, t.orderSignalId, "MARKET_EXIT", r));
    const find = async (id: string): Promise<{ status?: string; executedQty?: string | number } | null> => {
      try { return (await rest.getOrderByClientId(t.symbol, id)) as { status?: string; executedQty?: string | number }; }
      catch (err) { if (/-2013|does not exist|not found|-2011/i.test(err instanceof Error ? err.message : String(err))) return null; throw err; }
    };
    const mark = async (): Promise<void> => {
      if (t.timeoutSentAt) return;
      const now = this.now();
      await this.store.updateTrade(t.tradeId, { timeoutSentAt: now });
      t.timeoutSentAt = now;
    };
    let ours: Array<{ status?: string; executedQty?: string | number }>, amt: number;
    try {
      ours = [];
      for (const id of ids) { const o = await find(id); if (!o) break; ours.push(o); }
      amt = await positionAmt(rest, t.symbol);
    } catch (err) {
      await this.retried(t, u, `timeout close: Binance unreadable (${err instanceof Error ? err.message : String(err)})`);
      return false;
    }
    if (ours.some((o) => Number(o.executedQty) > 0)) await mark();
    const mine = amt !== 0 && Math.sign(amt) === (t.side === "LONG" ? 1 : -1);
    if (!mine) return true;                                                     // over -> the settle reports it
    if (ours.some((o) => o.status === "NEW" || o.status === "PARTIALLY_FILLED")) return false;   // our close is still working
    if (ours.length >= ids.length) { await this.retried(t, u, `timeout close: ${ids.length} market closes sent, the ${t.symbol} position (${amt}) is still there`); return false; }
    // never more than our own quantity (another trade's position is never touched); less is fine (our TP partly filled)
    if (t.quantity !== null && Math.abs(amt) > t.quantity * 1.001) { await this.retried(t, u, `timeout close: the ${t.symbol} position (${amt}) is bigger than ours (${t.quantity}) -- nothing touched`); return false; }
    const f = await getSymbolFilters(rest, t.symbol);
    if (!f) { await this.retried(t, u, "timeout close: symbol filters unreadable"); return false; }
    const qty = Math.min(Math.abs(amt), t.quantity ?? Math.abs(amt)), id = ids[ours.length];
    await rest.createOrder({ symbol: t.symbol, side: t.side === "LONG" ? "SELL" : "BUY", type: "MARKET", quantity: qty.toFixed(f.qtyPrecision), reduceOnly: "true", newClientOrderId: id });
    log.warn({ tradeId: t.tradeId, quantity: qty, revision: ours.length }, "[V10_WALL_TIMEOUT_CLOSE_SENT]");
    const o = await find(id).catch(() => null);
    if (o && Number(o.executedQty) > 0) await mark();
    return true;
  }

  private async openForAll(sig: V10SignalDoc): Promise<void> {
    for (const p of sig.picks) {
      const book = await this.bookFor(sig, p.symbol), zone = await this.zoneFor(sig, p);
      await Promise.all(this.users().map((u) => this.openTrade(u, sig, p, book, zone).catch((err) =>
        log.error({ userId: u.userId, signalId: sig.signalId, symbol: p.symbol, err: err instanceof Error ? err.message : String(err) }, "[V10_OPEN_TRADE_UNEXPECTED] -- isolated"))));
    }
  }

  private async openTrade(u: V10UserRef, sig: V10SignalDoc, p: V10Pick, bookView: V10BookView | null = null, zoneView: V10ZoneView | null | undefined = undefined): Promise<void> {
    if (u.mode === "OFF") return;
    const r = rulesFor(this.settings, u.userId);
    if (sig.kind === "BTC" ? !r.btc : !r.own) return;            // this user does not take this part
    if (sig.side === "SHORT" ? !r.short : !(sig.kind === "OWN" ? r.ownLong : r.long)) return;   // ... or this side (ALT LONGs: ownLong, Oct 4)
    const rules = sig.kind === "BTC" ? { ...r } : { ...r, slPct: r.ownSlPct, tpPct: r.ownTpPct };
    const orderSignalId = `${sig.signalId}:${p.symbol}`;
    const lv = levels(sig.side, p.price, rules.slPct, rules.tpPct);
    const base: V10TradeDoc = {
      tradeId: `${orderSignalId}:${u.userId}`, orderSignalId, signalId: sig.signalId, kind: sig.kind, userId: u.userId, mode: u.mode,
      symbol: p.symbol, side: sig.side, pick: { rank: p.rank, x: p.x, follow: p.follow, coinPct: p.coinPct, btcPct: p.btcPct },
      state: "OPEN", createdAt: sig.turn.candleEnd, entryPrice: null, slPrice: lv.sl, tpPrice: null, slPct: rules.slPct, tpPct: rules.tpPct,
      quantity: null, plannedRiskUsd: u.riskUsd, actualRiskUsd: null, binance: null,
      closedAt: null, exitPrice: null, pnlUsd: null, pnlR: null, feesUsd: null, closeReason: null, failureReason: null, closeAttempts: 0, entryInProgress: true, entryStartedAt: null,
      ...(bookView ? { book: bookView } : {}),
      ...(zoneView !== undefined ? { zone4h: zoneView } : {}),
    };
    const skip = async (reason: string, tell: boolean, state: "SKIPPED" | "FAILED" = "SKIPPED"): Promise<void> => {
      const t = { ...base, state, failureReason: reason, entryInProgress: false };
      if (!(await this.store.insertTrade(t))) {
        // the row exists (it was inserted as OPEN before an order) -> mark it
        await this.store.updateTrade(base.tradeId, { state, failureReason: reason, entryInProgress: false });
      }
      log.warn({ userId: u.userId, tradeId: base.tradeId, reason }, `[V10_TRADE_${state}]`);
      if (tell) await this.notify(u, formatV10Failure(t));
    };

    // Johnny Oct 3 (ETH +0.36%): the coin must have moved MORE than this user's TP -- we want back more than it went.
    // BTC part: the alt's own move with BTC (to its extreme); ALT part: the alt's move from its OI low to the top.
    const moved = moveOf(sig as Parameters<typeof moveOf>[0], p);
    if (!(moved > rules.tpPct)) return skip(`the move was only ${moved.toFixed(2)}%, not more than the TP ${rules.tpPct}% -- a quiet market, not taken`, false);

    // Oct 5: the price already gave back too much of its move at the entry (the giveback test's top quarter) -- per user
    const maxGb = sig.side === "SHORT" ? rules.maxGivebackShort : rules.maxGivebackLong;
    if (sig.kind === "OWN" && maxGb !== null) {
      const gb = givebackPct(sig.turn, p.price);
      if (gb >= maxGb) return skip(`GIVEBACK: the price already gave back ${gb.toFixed(0)}% of its move (>= ${maxGb}%) -- late -- maxGiveback${sig.side === "SHORT" ? "Short" : "Long"}`, false);
    }
    // Oct 5: a candle against the turn between the top (bottom) and the entry -- per user and side; unknown = not blocked
    if (sig.kind === "OWN" && sig.against?.length && (sig.side === "SHORT" ? rules.oiCandleShort : rules.oiCandleLong)) {
      const w = sig.against.map((a) => `${new Date(a.t).toISOString().slice(11, 16)} OI ${a.oiPct >= 0 ? "+" : ""}${a.oiPct.toFixed(2)}%`).join(", ");
      return skip(`OI CANDLE: ${sig.side === "SHORT" ? "a GREEN candle with OI DOWN after the top" : "a RED candle with OI UP after the bottom"} (${w}) -- oiCandle${sig.side === "SHORT" ? "Short" : "Long"}`, false);
    }
    // Oct 4: new coins -- per user and side
    if (sig.newCoin && (sig.side === "SHORT" ? !rules.newShort : !rules.newLong)) return skip(`${p.symbol} is a new coin (less than ${NEW_COIN_DAYS} days of data) -- new${sig.side === "SHORT" ? "Short" : "Long"} is off for this user`, false);
    // Oct 4: the 4h zone filters (per user; off = the zone is only shown)
    if (sig.side === "SHORT" && rules.zoneFilterShort) {
      const w = zoneWall(zoneView, "SHORT", p.price, lv.tp);
      if (w) return skip(`ZONE: a 4h zone ${+w.lo.toPrecision(5)} – ${+w.hi.toPrecision(5)} lies between the entry and the TP -- zoneFilterShort`, false);
    }
    // Oct 4: the order book filter -- the bids' share within 1% grew from the top to the entry (unknown = not blocked)
    if (sig.side === "SHORT" && rules.bookFilterShort && bookView?.grew === true)
      return skip(`BOOK: the buyers' share within 1% grew from the top to the entry (${bookView.supportTopPct?.toFixed(1)}% -> ${bookView.supportNowPct?.toFixed(1)}%) -- someone defends the price below -- bookFilterShort`, false);
    if (sig.side === "LONG" && rules.zoneFilterLong) {
      const d = zoneView?.strongBelowAtr;
      if (d === undefined || d === null || d > rules.zoneLongMaxAtr) return skip(`ZONE: ${d === undefined ? "the 4h zones are unknown" : d === null ? "no strong 4h zone under the entry" : `the strong 4h zone under the entry is ${d.toFixed(1)} ATR away (> ${rules.zoneLongMaxAtr})`} -- zoneFilterLong`, false);
    }

    const open = await this.store.findOpenTrades();
    // Oct 4: LONG and SHORT are independent -- one open trade per coin per SIDE (REAL: the account check below still
    // refuses a coin that has any position, so a REAL account never holds both)
    if (open.some((t) => t.userId === u.userId && t.symbol === p.symbol && t.side === sig.side)) return skip(`a V10 ${sig.side} on ${p.symbol} is already open for this user`, false);
    // Oct 7: a WALL trade on the coin (either side) -> the coin is busy for this user
    if (open.some((t) => t.userId === u.userId && t.symbol === p.symbol && t.kind === "WALL")) return skip(`a V10 WALL trade on ${p.symbol} is already open for this user`, false);
    if (rules.maxOpen !== null) {
      const mine = open.filter((t) => t.userId === u.userId && t.kind !== "WALL");   // Oct 7: WALL has its own limit
      if (mine.length >= rules.maxOpen) return skip(`MAX_OPEN: ${mine.length} V10 trades already open (${mine.map((t) => `${t.symbol} ${t.side}`).join(", ")}), limit ${rules.maxOpen}`, true);
    }

    if (u.mode === "PAPER") {
      const entry = p.price, risk = Math.abs(entry - lv.sl);
      if (!(entry > 0) || !(risk > 0)) return skip(`bad entry price ${entry}`, false, "FAILED");
      const t: V10TradeDoc = { ...base, entryPrice: entry, slPrice: lv.sl, tpPrice: lv.tp, quantity: u.riskUsd / risk, actualRiskUsd: u.riskUsd, entryInProgress: false };
      if (!(await this.store.insertTrade(t))) return;
      log.warn({ tradeId: t.tradeId, entry, sl: lv.sl, tp: lv.tp }, "[V10_PAPER_ENTRY]");
      await this.notify(u, formatV10Entry(sig, t));
      return;
    }

    // REAL
    const rest = u.binanceRest;
    if (u.mode !== "REAL" || !rest) return; // not REAL-capable (main.ts downgrades such users to PAPER)
    if (this.now() - sig.turn.candleEnd > STALE_MS) return skip("signal too old for a market entry", true);
    // Oct 12: the checks and our OPEN row under one lock per (user, symbol) -- V11 runs in the same process
    const prep = await withSymbolLock(u.userId, p.symbol, async (): Promise<{ row: V10TradeDoc; ref: number; lvl: ReturnType<typeof levels> } | null> => {
      if (await this.store.hasOpenOtherTrade(u.userId, p.symbol)) { await skip(`a REAL V11 trade on ${p.symbol} is open for this user -- V10 never trades on top of it`, true); return null; }
      const busy = await symbolClear(rest, p.symbol);
      if (busy) { await skip(`${busy} -- V10 never trades on top of it`, true); return null; }
      // SL / TP: the SAME prices as PAPER -- the configured % from the SIGNAL price (Johnny, Oct 2: UNI REAL entered
      // +1.1% above the signal, after PAPER's SL had already been passed, and got its own wider SL). If the price a market
      // order would get NOW is already at / beyond the SL or the TP, the signal is over -> not opened.
      const lvl = levels(sig.side, p.price, rules.slPct, rules.tpPct);
      const book = (await rest.getBookTicker?.(p.symbol).catch(() => null)) as { bidPrice?: string; askPrice?: string } | null;
      const exec = Number(sig.side === "SHORT" ? book?.bidPrice : book?.askPrice);
      if (!(exec > 0)) { await skip("no executable price from Binance", true); return null; }
      const short = sig.side === "SHORT";
      if (short ? exec >= lvl.sl : exec <= lvl.sl) { await skip(`the price already reached the SL: now ${exec}, signal ${p.price}, SL ${+lvl.sl.toPrecision(8)} -- the signal is over`, true); return null; }
      if (short ? exec <= lvl.tp : exec >= lvl.tp) { await skip(`the price already reached the TP: now ${exec}, signal ${p.price}, TP ${+lvl.tp.toPrecision(8)} -- too late`, true); return null; }
      const startedAt = this.now();
      const row: V10TradeDoc = { ...base, slPrice: lvl.sl, entryStartedAt: startedAt };
      if (!(await this.store.insertTrade(row))) return null; // already handled for this user
      this.entering.add(row.tradeId);
      return { row, ref: exec, lvl };
    });
    if (!prep) return;
    const { row, ref, lvl } = prep;
    try {
      const out = await runEntrySequence(rest, {
        userId: u.userId, globalSignalId: orderSignalId, symbol: p.symbol, side: sig.side,
        quantity: u.riskUsd / Math.abs(ref - lvl.sl), entryPriceEstimate: ref,
        slPrice: lvl.sl, initialTpPrice: lvl.tp,
        riskUsd: u.riskUsd, leverage: u.leverage, marginMode: u.marginMode,
      });
      if (out.outcome === "ENTRY_FAILED" || out.outcome === "PROTECTION_FAILED_CLOSED") {
        // never trusted blindly: the order may have filled although the call failed (timeout). The 15 s monitor looks
        // up OUR entry order on Binance and decides: not opened -> failed (+ message) / filled -> protected or closed.
        await this.store.updateTrade(row.tradeId, { failureReason: out.reason });
        log.error({ tradeId: row.tradeId, reason: out.reason, outcome: out.outcome }, "[V10_ENTRY_NOT_CONFIRMED] -- handed to the recovery");
        return;
      }
      const binance: V10TradeDoc["binance"] = {
        entryClientOrderId: out.entryClientOrderId, slAlgoId: out.slBinanceAlgoId, slClientAlgoId: out.slClientAlgoId,
        ...(out.outcome === "ENTRY_ACTIVE_WITH_TP" ? { tpOrderId: out.tpBinanceOrderId, tpClientOrderId: out.tpClientOrderId } : { tpFailureReason: out.tpFailureReason }),
      };
      const fields: Partial<V10TradeDoc> = { entryPrice: out.entryPrice, quantity: out.quantity, tpPrice: out.tpPrice ?? null, actualRiskUsd: out.actualRiskUsd ?? null, binance, entryInProgress: false };
      await this.store.updateTrade(row.tradeId, fields);
      log.warn({ tradeId: row.tradeId, ...fields }, "[V10_REAL_ENTRY]");
      await this.notify(u, formatV10Entry(sig, { ...row, ...fields } as V10TradeDoc));
    } finally {
      this.entering.delete(row.tradeId);
    }
  }

  // ── 2. PAPER exits ───────────────────────────────────────────────────────────────────────────────────────────
  private async monitorPaper(): Promise<void> {
    const now = this.now();
    const open = (await this.store.findOpenTrades()).filter((t) => t.mode === "PAPER" && !t.entryInProgress && t.entryPrice !== null && t.tpPrice !== null && t.slPrice !== null && t.quantity !== null);
    const bySymbol = new Map<string, V10TradeDoc[]>();
    for (const t of open) bySymbol.set(t.symbol, [...(bySymbol.get(t.symbol) ?? []), t]);
    for (const [symbol, list] of bySymbol) {
      const from = Math.min(...list.map((t) => t.createdAt));
      const bars = (await this.load(symbol, from, now)).filter((b) => b.t + M <= now); // closed minutes only
      for (const t of list) {
        const entry = t.entryPrice!, risk = Math.abs(entry - t.slPrice!), rr = Math.abs(t.tpPrice! - entry) / risk;
        // WALL (Oct 7): only the minutes before its timeout count; still open then -> closed at that minute's close
        const deadline = t.kind === "WALL" && t.timeoutAt !== undefined ? t.timeoutAt : Infinity;
        const use = deadline < Infinity ? bars.filter((b) => b.t < deadline) : bars;
        const tr = simTrade(use, t.createdAt, entry, t.slPrice!, rr, t.side === "SHORT" ? "DOWN" : "UP");
        if (tr.exit === "OPEN") {
          const lastBar = use[use.length - 1] ?? (now >= deadline + 5 * M ? bars[bars.length - 1] : undefined);
          if (deadline < Infinity && lastBar && (lastBar.t + M >= deadline || now >= deadline + 5 * M)) {
            const sg = t.side === "LONG" ? 1 : -1, fees = estimateFeesUsd(entry * t.quantity!), riskUsd = t.actualRiskUsd ?? t.plannedRiskUsd;
            const pnlUsd = sg * (lastBar.close - entry) * t.quantity! - fees.sl;
            await this.closeTrade(t, { closedAt: Math.min(deadline, lastBar.t + M), exitPrice: lastBar.close, pnlUsd, pnlR: pnlUsd / riskUsd, feesUsd: fees.sl, closeReason: "TIMEOUT_CLOSED" });
          }
          continue;
        }
        const fees = estimateFeesUsd(entry * t.quantity!), riskUsd = t.actualRiskUsd ?? t.plannedRiskUsd;
        const feesUsd = tr.exit === "TP" ? fees.tp : fees.sl;
        const pnlUsd = (tr.exit === "TP" ? rr * riskUsd : -riskUsd) - feesUsd;
        await this.closeTrade(t, { closedAt: tr.exitT, exitPrice: tr.exit === "TP" ? t.tpPrice : t.slPrice, pnlUsd, pnlR: pnlUsd / riskUsd, feesUsd, closeReason: tr.exit === "TP" ? "TP_FILLED" : "SL_FILLED" });
      }
    }
  }

  // ── 3. REAL exits ────────────────────────────────────────────────────────────────────────────────────────────
  /** Public for tests. */
  async monitorReal(): Promise<void> {
    if (this.monitorBusy) return;
    this.monitorBusy = true;
    try {
      const users = new Map(this.users().map((u) => [u.userId, u]));
      for (const t of await this.store.findOpenTrades()) {
        if (t.mode !== "REAL" || this.entering.has(t.tradeId)) continue;
        const u = users.get(t.userId);
        const rest = u?.binanceRest ?? u?.monitorRest ?? null;
        if (!u || !rest) {
          log.error({ tradeId: t.tradeId, userId: t.userId }, "[V10_REAL_UNWATCHED] -- no Binance client for this user; check the trade on Binance");
          continue;
        }
        try {
          if (t.entryInProgress) {
            // not running in this process: after a failed call at once, after a crash / restart once it is surely over
            if (t.failureReason !== null || this.now() - (t.entryStartedAt ?? t.createdAt) >= STUCK_ENTRY_MS) await this.recover(t, u, rest);
            continue;
          }
          await this.checkRealTrade(t, u, rest);
        } catch (err) {
          log.error({ tradeId: t.tradeId, err: err instanceof Error ? err.message : String(err) }, "[V10_REAL_MONITOR_FAILED] -- retried next cycle");
        }
      }
    } finally {
      this.monitorBusy = false;
    }
  }

  /** an entry that did not finish normally -- decided from OUR entry order on Binance (see recoverEntry) */
  private async recover(t: V10TradeDoc, u: V10UserRef, rest: SettleRest): Promise<void> {
    const r = await recoverEntry(rest, { userId: t.userId, orderSignalId: t.orderSignalId, symbol: t.symbol, side: t.side, binance: t.binance });
    const head = `⚠️ ${v10Head(t)} · ${t.symbol} · ${t.side} · REAL`;
    if (r.status === "RETRY") return this.retried(t, u, `recovery: ${r.why}`);
    if (t.retries) await this.store.updateTrade(t.tradeId, { retries: 0 });
    if (r.status === "NOT_OPENED") {
      const reason = t.failureReason ?? "entry never completed";
      await this.store.updateTrade(t.tradeId, { state: "FAILED", failureReason: reason, entryInProgress: false });
      log.warn({ tradeId: t.tradeId, reason }, "[V10_TRADE_FAILED]");
      await this.notify(u, formatV10Failure({ ...t, state: "FAILED", failureReason: reason }));
      return;
    }
    if (r.status === "DONE") {
      // our entry filled and the position is already gone (closed while we were away) -> the normal close report
      await this.store.updateTrade(t.tradeId, { entryInProgress: false, entryPrice: r.entryPrice, quantity: r.quantity });
      log.warn({ tradeId: t.tradeId }, "[V10_RECOVERY_DONE] -- settled next cycle");
      return;
    }
    if (r.status === "ADOPTED") {
      let tpOrderId = r.tpOrderId, tpPrice: number | null = null;
      if (tpOrderId === null) ({ tpOrderId, tpPrice } = await this.placeTp(t, rest, r.entryPrice, r.quantity));
      const binance = { ...(t.binance ?? {}), slAlgoId: r.slAlgoId, ...(tpOrderId !== null ? { tpOrderId } : {}) };
      await this.store.updateTrade(t.tradeId, { entryPrice: r.entryPrice, quantity: r.quantity, entryInProgress: false, binance, failureReason: null, ...(tpPrice !== null ? { tpPrice } : {}) });
      log.warn({ tradeId: t.tradeId, binance }, "[V10_RECOVERY_ADOPTED]");
      await this.notify(u, `${head}\nThe entry did not finish normally${t.failureReason ? ` (${t.failureReason})` : ""}, but it is open on Binance with its SL resting -- the bot follows it as a normal trade${tpOrderId === null ? " (no TP: it closes at the SL or by hand)" : ""}.\n🆔 ${t.orderSignalId}`);
      return;
    }
    await this.store.updateTrade(t.tradeId, { entryInProgress: false, entryPrice: r.entryPrice, quantity: r.quantity, binance: null, failureReason: `${FAILSAFE_NOTE}${t.failureReason ? ` (${t.failureReason})` : ""}` });
    log.error({ tradeId: t.tradeId, quantity: r.quantity }, "[V10_RECOVERY_CLOSED_UNPROTECTED]");
    await this.notify(u, `${head}\nThe entry filled on Binance but its SL was not there -- the position was closed at market. The close report follows.\n🆔 ${t.orderSignalId}`);
  }

  /** an adopted trade without its TP: the TP is placed (reduce-only LIMIT, our deterministic client id) */
  private async placeTp(t: V10TradeDoc, rest: SettleRest, entry: number, qty: number): Promise<{ tpOrderId: number | null; tpPrice: number | null }> {
    try {
      const f = await getSymbolFilters(rest, t.symbol);
      if (!f) return { tpOrderId: null, tpPrice: null };
      // WALL: the signal's own TP price (the same as PAPER); the other parts: the % from the entry
      const tp = roundToStep(t.kind === "WALL" && t.wall ? t.wall.tp : levels(t.side, entry, t.slPct, t.tpPct).tp, f.tickSize, f.pricePrecision);
      const res = (await rest.createOrder({
        symbol: t.symbol, side: t.side === "LONG" ? "SELL" : "BUY", type: "LIMIT", timeInForce: "GTC", price: tp.toFixed(f.pricePrecision),
        quantity: qty.toFixed(f.qtyPrecision), reduceOnly: "true", newClientOrderId: ourIds(t.userId, t.orderSignalId).tp,
      })) as { orderId?: number };
      return { tpOrderId: Number(res?.orderId) > 0 ? Number(res.orderId) : null, tpPrice: tp };
    } catch (err) {
      log.error({ tradeId: t.tradeId, err: err instanceof Error ? err.message : String(err) }, "[V10_TP_PLACE_FAILED] -- the trade stays under its SL");
      return { tpOrderId: null, tpPrice: null };
    }
  }

  /** a REAL trade that keeps failing to be read / settled: logged every time, the user told once after ~5 min IN A ROW
   *  (the counter goes back to 0 as soon as a cycle succeeds) */
  private async retried(t: V10TradeDoc, u: V10UserRef, why: string): Promise<void> {
    const n = (t.retries ?? 0) + 1;
    await this.store.updateTrade(t.tradeId, { retries: n });
    log.warn({ tradeId: t.tradeId, why, retries: n }, "[V10_REAL_RETRY]");
    if (n === RETRY_ALERT) await this.notify(u, `⚠️ ${v10Head(t)} · ${t.symbol} · ${t.side} · REAL\nThe bot cannot settle this trade for ~5 min: ${why}\nPlease look at ${t.symbol} on Binance.\n🆔 ${t.orderSignalId}`);
  }

  private async checkRealTrade(t: V10TradeDoc, u: V10UserRef, rest: SettleRest): Promise<void> {
    // WALL (Oct 7): past its timeout -> our market close first (once); the settle below reports it
    if (t.kind === "WALL" && t.timeoutAt !== undefined && t.entryPrice !== null && this.now() >= t.timeoutAt) {
      if (!(await this.timeoutClose(t, u, rest))) return;
    }
    const other = await this.store.openOtherTradeSince(t.userId, t.symbol, t.entryStartedAt ?? t.createdAt);
    const r = await settle(rest, { userId: t.userId, orderSignalId: t.orderSignalId, symbol: t.symbol, side: t.side, entryStartedAt: t.entryStartedAt ?? t.createdAt, quantity: t.quantity, binance: t.binance }, this.now(), other);
    if (r.status === "RETRY") return this.retried(t, u, r.why);
    if (t.retries) await this.store.updateTrade(t.tradeId, { retries: 0 });
    if (r.status === "OPEN") return;
    if (r.status === "NO_FILLS") {
      if (t.entryPrice === null && this.now() - t.createdAt >= STUCK_ENTRY_MS) {
        await this.store.updateTrade(t.tradeId, { state: "FAILED", failureReason: "entry never completed (no fill found)", entryInProgress: false });
        return;
      }
      const attempts = t.closeAttempts + 1;
      if (attempts < MAX_CLOSE_REPORT_ATTEMPTS) { await this.store.updateTrade(t.tradeId, { closeAttempts: attempts }); return; }
      await this.closeTrade(t, { closedAt: this.now(), exitPrice: null, pnlUsd: null, pnlR: null, feesUsd: null, closeReason: "CLOSED_NO_FILLS_FOUND" }, u);
      return;
    }
    const risk = t.actualRiskUsd ?? t.plannedRiskUsd;
    // closed by the bot's own fail-safe (not by the user / Binance): an entry problem was the reason it happened
    const failsafe = r.report.reason === "POSITION_CLOSED_EXTERNALLY" && t.failureReason !== null;
    // WALL: closed by our own timeout market order
    const timedOut = r.report.reason === "POSITION_CLOSED_EXTERNALLY" && t.timeoutSentAt !== undefined;
    await this.closeTrade(t, {
      closedAt: this.now(), exitPrice: r.report.exitPrice, pnlUsd: r.report.realizedPnlUsd,
      pnlR: risk > 0 ? r.report.realizedPnlUsd / risk : null, feesUsd: r.report.feesUsd, closeReason: timedOut ? "TIMEOUT_CLOSED" : failsafe ? "FAILSAFE_CLOSED" : r.report.reason,
    }, u);
  }

  private async closeTrade(t: V10TradeDoc, c: Pick<V10TradeDoc, "closedAt" | "exitPrice" | "pnlUsd" | "pnlR" | "feesUsd" | "closeReason">, user?: V10UserRef): Promise<void> {
    await this.store.updateTrade(t.tradeId, { state: "CLOSED", entryInProgress: false, ...c });
    log.warn({ tradeId: t.tradeId, ...c }, "[V10_TRADE_CLOSED]");
    const u = user ?? this.users().find((x) => x.userId === t.userId);
    if (u) await this.notify(u, formatV10Close({ ...t, state: "CLOSED", ...c }));
  }

  private async notify(u: V10UserRef, text: string): Promise<void> {
    if (!u.telegram) return;
    try { await u.telegram.sendMessage(text); } catch (err) {
      log.error({ userId: u.userId, err: err instanceof Error ? err.message : String(err) }, "[V10_TELEGRAM_FAILED] -- isolated");
    }
  }
}
