import type { V9FrameInfo } from "./v9-frame-core";
import {
  MINUTE_MS,
  buildReference,
  changePoints,
  episodeFeatures,
  mergeEpisodes,
  selectEpisode,
  subEpisodes,
  usableRange,
  typicalLiquidationMinuteUsd,
  median,
  type Bucket,
  type Episode,
  type EpisodeFeatures,
  type Regime,
  type SubEpisode,
  type SelectionReference,
  type SelectionResult,
  type Victim,
} from "./v9-core";
import { V9MinuteStore } from "./v9-minute-store";
import { priceOiEpisodes, typicalMinuteNoise } from "./v9-price-oi";
import { TAKER_FEE } from "./v9-fees";

/**
 * Causal (live) V9 engine for ONE symbol.
 *
 * Research ran the pipeline once over a finished dataset (look-ahead). Live,
 * evaluate(now) runs the SAME pure pipeline on data up to `now` only:
 *   - OI regimes are fitted on the trailing window ending at now;
 *   - an episode is acted on only once its end is CONFIRMED (confirmTs <= now);
 *   - CLR/MOV medians come only from episodes confirmed BEFORE this one.
 *
 * Every confirmed episode becomes a decision (selected or not, with reasons)
 * so the operator can audit why a signal did or did not fire.
 */
export interface V9EngineSettings {
  /** Trailing data window for the regime fit. Research used ~3 days. */
  windowMs: number;
  /** Trailing window of prior confirmed DIR episodes for the medians. */
  referenceWindowMs: number;
  /** Medians of fewer samples are not meaningful: no selection below this. */
  minReferenceSamples: number;
  /** A confirmation discovered later than this after confirmTs (e.g. after
   *  a data gap or a regime re-fit) is recorded but never traded. */
  maxSignalAgeMs: number;
  /** How the end of an episode is confirmed:
   *   OPPOSITE_LIQ  an opposite-side liquidation part with an OI drop (research v9)
   *   PRICE_OI      OI falling while price moves against the liquidation move
   *                 (the other side is being closed) -- see v9-price-oi.ts */
  confirmMode: "OPPOSITE_LIQ" | "PRICE_OI";
  /** SL anchor: extreme price since the episode START, or since its PEAK
   *  liquidation minute (ignores early small liquidations). */
  slFrom: "START" | "PEAK";
  /** PRICE_OI only: require the OI drop AND the price reversal to exceed this
   *  symbol's typical one-minute noise (median over the data window). */
  significantConfirm: boolean;
  /** Extra room beyond the extreme for the SL, in units of the symbol's
   *  typical one-minute high-low range over the last hour (0 = none). */
  slBufferMinuteRanges: number;
  /** Which filters must pass: ALL five, only DOM, or NONE (every confirmation). */
  filters: "ALL" | "DOM" | "NONE";
  /** OPPOSITE_LIQ only: the confirming opposite liquidations must be at least
   *  this symbol's typical liquidation-minute size (median, from the data). */
  significantOppositeLiq: boolean;
  /** with significantOppositeLiq: the confirming liquidations must reach this
   *  many x the typical liquidation-minute size (1 = typical). */
  oppositeLiqMult: number;
  /** BREAKOUT (Johnny, Sep 26 2026): after a cleaning + accumulation, the
   *  first next liquidation part with an OI drop confirms, WHICHEVER side;
   *  the trade follows it (SHORT liq -> BUY, LONG liq -> SELL). The five
   *  checks still judge the cleaning. false = classic V9 (opposite side only,
   *  trade side = the cleaning's victims). */
  breakoutConfirm: boolean;
  /** DIRECTION CHECK (Johnny, Sep 26 2026): from the OI turn (where the
   *  confirming OI drop started) to the decision, the price must have moved
   *  OUR way (up for a BUY, down for a SELL); otherwise WRONG_DIRECTION. */
  requireTurnDirection: boolean;
  /** QUALITY FILTERS (Johnny, Sep 26 2026), each vs the medians of this
   *  coin's previous episodes (same reference window, only the past):
   *   requireForced     victim liquidations $ / OI drop $ >= median
   *                     (the cleaning was FORCED, not voluntary closing)
   *   requireSize       victim liquidations $ >= median (a big cleaning for this coin)
   *   requireAccAgainst during the accumulation (OI bottom -> OI turn) the
   *                     price kept going the cleaning's way = the new
   *                     positions were opened against us = fuel for the reversal */
  requireForced: boolean;
  requireSize: boolean;
  requireAccAgainst: boolean;
  /** 1H STRUCTURE (Johnny, Sep 27 2026): skip the trade when its TP lies
   *  beyond the level whose break would change the 1-hour structure -- for a
   *  SELL the last confirmed 1h swing LOW, for a BUY the last 1h swing HIGH.
   *  Swing = candle whose low (high) is below (above) the `tpStructureSwing`
   *  candles on EACH side (1 = the 3-candle rule, 2 = 5 candles); only
   *  complete hours, only the past. null = off. TP = entry +- tpRr x risk. */
  tpStructureSwing: number | null;
  tpRr: number;
  /** Skip a signal whose SL is so close that Binance fees on a stop-out would
   *  exceed this many R (null = never skip). */
  maxSlFeeR: number | null;
  /** Minimum SL distance as a fraction of price (0.0033 = 0.33%). A tighter
   *  stop is moved out to this distance (and the TP follows as rr x risk);
   *  wider stops are unchanged. Keeps stop-out fees <= ~0.3R and the position
   *  size <= ~300x the risk. 0 = off. */
  minSlFraction: number;
  /** LATE-ENTRY STOP (Johnny, Sep 25 2026): when the stop at the episode
   *  extreme is farther than this % from the entry (we are "very late"),
   *  the stop moves to where the confirming OI drop STARTED: the extreme
   *  price since the OI peak between the episode end and the confirmation.
   *  Used only if it is closer than the extreme stop. 0 = always, null = off. */
  lateSlPct: number | null;
  /** (Johnny, Sep 26) the OITURN stop is used only if it is at least this %
   *  from the entry; closer (noise) -> lateSlClamp false: the stop STAYS at
   *  the episode extreme; true: the stop is placed at exactly this distance.
   *  null = no minimum. */
  lateSlMinPct: number | null;
  lateSlClamp: boolean;
  /** SHARP ACCUMULATION (Johnny, Sep 25 2026): after the cleaning, new
   *  positions must open FAST and in size. Measure: the biggest OI rise in any
   *  30-minute window between the episode's OI bottom and the OI peak before
   *  the confirmation. It must reach this percentile (e.g. 70 or 90) of the
   *  coin's own 30-minute OI rises over the data window before the
   *  confirmation. null = off. */
  minAccumPercentile: number | null;
  /** OI REGROWTH (Johnny, Sep 25 2026) -- no time windows: at the signal,
   *  look back. The cleaning closed D coins (episode start OI -> its OI
   *  bottom). Between that bottom and the OI turn (where the confirming drop
   *  started) OI grew by G coins. Trade only if G >= this share of D
   *  (0.5 = half of the closed positions were re-opened). null = off. */
  minRegrowShare: number | null;
}

export const DEFAULT_V9_ENGINE_SETTINGS: V9EngineSettings = {
  windowMs: 3 * 24 * 3_600_000,
  referenceWindowMs: 3 * 24 * 3_600_000,
  minReferenceSamples: 5,
  maxSignalAgeMs: 2 * MINUTE_MS,
  confirmMode: "OPPOSITE_LIQ",
  slFrom: "START",
  significantConfirm: false,
  slBufferMinuteRanges: 0,
  filters: "ALL",
  significantOppositeLiq: false,
  oppositeLiqMult: 1,
  breakoutConfirm: false,
  requireTurnDirection: false,
  requireForced: false,
  requireSize: false,
  requireAccAgainst: false,
  tpStructureSwing: null,
  tpRr: 2.2,
  maxSlFeeR: null,
  minSlFraction: 0,
  lateSlPct: null,
  lateSlMinPct: null,
  lateSlClamp: false,
  minAccumPercentile: null,
  minRegrowShare: null,
};

export interface V9Decision {
  symbol: string;
  episode: Episode;
  features: EpisodeFeatures;
  reference: SelectionReference;
  selection: SelectionResult;
  /** true only when selected AND fresh AND the reference is large enough. */
  tradable: boolean;
  reason:
    | "SELECTED"
    | "NOT_SELECTED"
    | "REFERENCE_TOO_SMALL"
    | "STALE_CONFIRMATION"
    | "DUPLICATE_EPISODE"
    | "DATA_GAP"
    | "SL_TOO_TIGHT"
    | "ACCUM_WEAK"
    | "WRONG_DIRECTION"
    | "NOT_FORCED"
    | "SMALL_CLEANING"
    | "ACC_NOT_AGAINST"
    | "TP_BEYOND_STRUCTURE"
    | "SYMBOL_BUSY";
  /** Whole minutes between episode start and the decision with no data at all. */
  missingMinutes: number;
  evaluatedAt: number;
  /** Trade plan (fade): LONG victims -> BUY, SHORT victims -> SELL. */
  tradeSide: Victim;
  /** Episode extreme from its start through `evaluatedAt` (SL anchor). */
  stopPrice: number;
  referencePrice: number;
  /** The episode told in three phases for the entry message (tradable decisions only). */
  story?: V9Story;
  /** FORCED quality (every decision): victim liquidations $ / closed OI $, vs
   *  the median of this coin's previous episodes. weak = below that median
   *  (false when there is no history yet). */
  quality?: { forcedPct: number; forcedMedianPct: number; weak: boolean };
  /** The 4h frame check (set by the live service for tradable decisions; see v9-frame-core). */
  frame?: V9FrameInfo;
  /** Did BTC bring the coin here? (set by the live service for tradable decisions; information only, see preMove) */
  btcCheck?: {
    byBtc: boolean;
    coinPct: number;
    btcPct: number;
    btcPart: number;
    own: number;
    beta: number;
    /** the price direction of the move that brought the coin here (BTC's part when byBtc, else the coin's own part) */
    up: boolean;
    /** Johnny, Oct 1: BTC brought it and we trade AGAINST that move, or the coin did it alone and we trade WITH it */
    good: boolean;
  } | null;
  /** 1h structure level the TP was checked against (when tpStructureSwing is on). */
  structure?: {
    level: number | null;
    levelTs: number | null;
    tp: number;
    blocked: boolean;
  };
}

/** CLEANING (start -> lowest OI) -> NEW POSITIONS (lowest OI -> OI turn) ->
 *  TURN (OI turn -> decision), with warnings about weak points. Coins = OI units. */
export interface V9Story {
  victim: Victim;
  cleaning: {
    from: number;
    to: number;
    liqUsd: number;
    biggestTs: number;
    biggestUsd: number;
    coins: number;
    oiPct: number;
    priceFrom: number;
    priceTo: number;
  };
  accumulation: {
    from: number;
    to: number;
    coins: number;
    oiPct: number;
    priceFrom: number;
    priceTo: number;
  } | null;
  turn: {
    from: number;
    to: number;
    coins: number;
    side: Victim;
    liqUsd: number;
    priceFrom: number;
    priceTo: number;
  } | null;
  checksPassed: number;
  checksTotal: number;
  warnings: Array<
    | { kind: "SMALL_CONFIRM"; liqUsd: number; typicalUsd: number }
    | { kind: "AGAINST_NOW"; movePct: number }
    | { kind: "AGAINST_TREND"; changePct: number }
    | { kind: "NOT_FORCED"; forcedPct: number; medianPct: number }
  >;
}

interface ReferenceSample {
  confirmTs: number;
  clr: number;
  dirMove: number;
  forced: number;
  victimLiq: number;
}

/** What the engine sees RIGHT NOW for a symbol: the episode that is still
 *  forming (not yet confirmed), or none. Persisted every minute so an
 *  episode's live evolution can be replayed and audited later. */
export interface V9EpisodeSnapshot {
  symbol: string;
  ts: number;
  oiPhase: "OI_FALLING" | "OI_RISING" | "OI_FLAT";
  oi: number;
  price: number;
  forming: null | {
    start: number;
    victim: Victim;
    parts: number;
    longUsd: number;
    shortUsd: number;
    oiDropPct: number;
    priceMovePct: number;
    dom: boolean;
    dir: boolean;
    exh: boolean;
    clr: number;
  };
}

/** Shared per-minute episode computation for multi-variant replays. */
export type EpisodeCache = Map<
  string,
  {
    usable: Bucket[];
    regimes: Regime[];
    episodes?: Episode[];
    subs?: SubEpisode[];
  }
>;

export class V9CausalEngine {
  readonly store = new V9MinuteStore();
  private lastConfirmTs = -Infinity;
  private readonly reference: ReferenceSample[] = [];
  /** Time of the last TRADABLE decision per victim side. The regime fit is
   *  re-done every minute, so the same liquidation episode can re-appear
   *  with a later confirmation (seen in replay: SOL 15:53 signalled three
   *  times). Any selected episode that STARTED before the last tradable
   *  signal on the same side is the same move seen again -- never traded twice. */
  private readonly lastTradableAt: Record<Victim, number> = {
    LONG: -Infinity,
    SHORT: -Infinity,
  };

  /** Latest snapshot produced by evaluate(). */
  lastSnapshot: V9EpisodeSnapshot | null = null;

  /** `cache` (replay only): engines fed IDENTICAL data at the same minute can
   *  share the expensive part (regime fit + episodes) -- it depends only on
   *  the data and the episode-shaping settings, never on the decision rules. */
  constructor(
    readonly symbol: string,
    private readonly settings: V9EngineSettings = DEFAULT_V9_ENGINE_SETTINGS,
    private readonly cache?: EpisodeCache,
  ) {}

  /** Restore "this side was already traded at `ts`" after a restart, from
   *  the persisted trades -- so a re-confirmed old episode is never traded twice. */
  markTraded(side: Victim, ts: number): void {
    this.lastTradableAt[side] = Math.max(this.lastTradableAt[side], ts);
  }

  /** Evaluate with all data up to `now`. Returns decisions for episodes whose
   *  end became known since the previous call, oldest first. */
  evaluate(now: number): V9Decision[] {
    const from = now - this.settings.windowMs;
    this.store.prune(from - MINUTE_MS);
    // the costly part (regime fit, sub-episodes) depends only on the data; the
    // episode grouping depends on the confirmation settings (cheap)
    const baseKey = `${now}|${this.settings.windowMs}`;
    let base = this.cache?.get(baseKey);
    if (!base) {
      const usable0 = usableRange(this.store.toBuckets(from, now));
      if (usable0 === null) return [];
      const regimes0 = changePoints(usable0.map((b) => b.oi));
      base = { usable: usable0, regimes: regimes0 };
      this.cache?.set(baseKey, base);
    }
    const key = `${baseKey}|${this.settings.confirmMode}|${this.settings.significantConfirm}|${this.settings.significantOppositeLiq}|${this.settings.oppositeLiqMult}|${this.settings.breakoutConfirm}`;
    let shaped = this.cache?.get(key);
    if (!shaped) {
      const { usable: usable0, regimes: regimes0 } = base;
      let episodes0: Episode[];
      if (this.settings.confirmMode === "PRICE_OI") {
        episodes0 = priceOiEpisodes(
          usable0,
          regimes0,
          now,
          this.settings.significantConfirm
            ? typicalMinuteNoise(usable0)
            : undefined,
        );
      } else {
        if (!base.subs) base.subs = subEpisodes(usable0, regimes0, now);
        episodes0 = mergeEpisodes(
          usable0,
          base.subs,
          this.settings.significantOppositeLiq
            ? this.settings.oppositeLiqMult *
                typicalLiquidationMinuteUsd(usable0)
            : undefined,
          this.settings.breakoutConfirm,
        );
      }
      shaped = { usable: usable0, regimes: regimes0, episodes: episodes0 };
      this.cache?.set(key, shaped);
    }
    const { usable, regimes } = shaped;
    const episodes = shaped.episodes!;
    this.lastSnapshot = this.snapshot(now, usable, regimes, episodes);

    const fresh = episodes
      .filter(
        (e) =>
          Number.isFinite(e.confirmTs) &&
          e.confirmTs <= now &&
          e.confirmTs > this.lastConfirmTs,
      )
      .sort((a, b) => a.confirmTs - b.confirmTs);

    const decisions: V9Decision[] = [];
    for (const e of fresh) {
      const features = episodeFeatures(usable, e);
      const prior = this.reference.filter(
        (r) =>
          r.confirmTs < e.confirmTs &&
          r.confirmTs >= e.confirmTs - this.settings.referenceWindowMs,
      );
      const reference = buildReference(prior);
      const full = selectEpisode(features, reference);
      const selection =
        this.settings.filters === "ALL"
          ? full
          : {
              ...full,
              selected: this.settings.filters === "NONE" ? true : features.dom,
            };
      const stale = now - e.confirmTs > this.settings.maxSignalAgeMs;
      const small =
        this.settings.filters === "ALL" &&
        reference.sampleCount < this.settings.minReferenceSamples;
      const duplicate = e.start < this.lastTradableAt[e.victim];
      // Minutes with no poll at all = the collector was down (restart,
      // outage). Liquidations of that time are lost for good (Binance keeps
      // no history), so such an episode is not trusted with money.
      // (the current minute is still in progress and is not checked)
      const lastFull = now - MINUTE_MS;
      const expectedMinutes =
        Math.floor(lastFull / MINUTE_MS) - Math.floor(e.start / MINUTE_MS) + 1;
      const missingMinutes = Math.max(
        0,
        expectedMinutes - this.store.minuteRange(e.start, lastFull).length,
      );
      // trade side: WITH the confirming liquidations (SHORT liq -> BUY). Classic V9: = the cleaning's victims.
      const side: Victim = e.confirmSide
        ? e.confirmSide === "SHORT"
          ? "LONG"
          : "SHORT"
        : e.victim;
      const extreme = this.store.extremePrice(
        side === "LONG" ? "LOW" : "HIGH",
        this.settings.slFrom === "PEAK" ? features.peakTs : e.start,
        now,
      );
      const buffer =
        this.settings.slBufferMinuteRanges > 0
          ? this.settings.slBufferMinuteRanges * this.typicalMinuteRange(now)
          : 0;
      const refPrice = this.store.lastPrice(now);
      let stopPrice = side === "LONG" ? extreme - buffer : extreme + buffer;
      if (
        this.settings.lateSlPct !== null &&
        refPrice > 0 &&
        (Math.abs(refPrice - stopPrice) / refPrice) * 100 >
          this.settings.lateSlPct
      ) {
        const turnTs = oiTurnTs(usable, e);
        if (turnTs !== null) {
          const turn = this.store.extremePrice(
            side === "LONG" ? "LOW" : "HIGH",
            turnTs,
            now,
          );
          const t = side === "LONG" ? turn - buffer : turn + buffer;
          const valid =
            side === "LONG"
              ? t < refPrice && t > stopPrice
              : t > refPrice && t < stopPrice;
          if (Number.isFinite(t) && valid) {
            const minD =
              this.settings.lateSlMinPct === null
                ? 0
                : (refPrice * this.settings.lateSlMinPct) / 100;
            if (Math.abs(refPrice - t) >= minD) stopPrice = t;
            else if (this.settings.lateSlClamp) {
              const c = side === "LONG" ? refPrice - minD : refPrice + minD;
              if (side === "LONG" ? c > stopPrice : c < stopPrice)
                stopPrice = c; // never farther than the extreme
            }
            // else: the turn is too close to the entry (noise) -> the stop stays at the extreme
          }
        }
      }
      const minDist = refPrice * this.settings.minSlFraction;
      if (minDist > 0 && Math.abs(refPrice - stopPrice) < minDist)
        stopPrice = side === "LONG" ? refPrice - minDist : refPrice + minDist;
      const riskDist = Math.abs(refPrice - stopPrice);
      const slFeeR =
        riskDist > 0 ? (2 * TAKER_FEE * refPrice) / riskDist : Infinity;
      const tooTight =
        this.settings.maxSlFeeR !== null && slFeeR > this.settings.maxSlFeeR;
      const regrow =
        this.settings.minRegrowShare !== null ? regrowShare(usable, e) : null;
      const accumWeak =
        (this.settings.minAccumPercentile !== null &&
          !sharpAccumulation(usable, e, this.settings.minAccumPercentile)) ||
        (this.settings.minRegrowShare !== null &&
          !(regrow !== null && regrow >= this.settings.minRegrowShare));
      const wrongDirection =
        this.settings.requireTurnDirection &&
        !turnDirectionOk(usable, e, side, refPrice);
      const forced = forcedShare(e, features.victimLiq);
      const notForced =
        this.settings.requireForced &&
        !(forced >= median(prior.map((r) => r.forced)));
      const smallCleaning =
        this.settings.requireSize &&
        !(features.victimLiq >= median(prior.map((r) => r.victimLiq)));
      const accNotAgainst =
        this.settings.requireAccAgainst && !accumulationAgainst(usable, e);
      let structure: V9Decision["structure"];
      if (this.settings.tpStructureSwing !== null && refPrice > 0) {
        const tp =
          side === "LONG"
            ? refPrice + this.settings.tpRr * Math.abs(refPrice - stopPrice)
            : refPrice - this.settings.tpRr * Math.abs(refPrice - stopPrice);
        const candles = hourCandles(
          this.store.minuteRange(now - 48 * 3_600_000, now),
          now,
        );
        const sw = lastSwing(
          candles,
          side === "LONG" ? "HIGH" : "LOW",
          this.settings.tpStructureSwing,
        );
        const blocked =
          sw !== null && (side === "LONG" ? tp > sw.price : tp < sw.price);
        structure = {
          level: sw?.price ?? null,
          levelTs: sw?.ts ?? null,
          tp,
          blocked,
        };
      }
      const reason: V9Decision["reason"] = !selection.selected
        ? "NOT_SELECTED"
        : small
          ? "REFERENCE_TOO_SMALL"
          : stale
            ? "STALE_CONFIRMATION"
            : duplicate
              ? "DUPLICATE_EPISODE"
              : missingMinutes > 0
                ? "DATA_GAP"
                : tooTight
                  ? "SL_TOO_TIGHT"
                  : accumWeak
                    ? "ACCUM_WEAK"
                    : wrongDirection
                      ? "WRONG_DIRECTION"
                      : notForced
                        ? "NOT_FORCED"
                        : smallCleaning
                          ? "SMALL_CLEANING"
                          : accNotAgainst
                            ? "ACC_NOT_AGAINST"
                            : structure?.blocked
                              ? "TP_BEYOND_STRUCTURE"
                              : "SELECTED";
      const story =
        reason === "SELECTED"
          ? buildV9Story(
              usable,
              e,
              features.victimLiq,
              side,
              refPrice,
              this.store.lastPrice(now - 3 * MINUTE_MS),
              now,
              selection,
              forced,
              median(prior.map((r) => r.forced)),
            )
          : undefined;
      decisions.push({
        symbol: this.symbol,
        episode: e,
        features,
        reference,
        selection,
        tradable: reason === "SELECTED",
        reason,
        evaluatedAt: now,
        missingMinutes,
        tradeSide: side,
        stopPrice,
        referencePrice: refPrice,
        story,
        structure,
        quality: (() => {
          const m = median(prior.map((r) => r.forced));
          return {
            forcedPct: forced * 100,
            forcedMedianPct: m * 100,
            weak: Number.isFinite(forced) && Number.isFinite(m) && forced < m,
          };
        })(),
      });
      if (reason === "SELECTED") this.lastTradableAt[e.victim] = now;
      if (features.dir)
        this.reference.push({
          confirmTs: e.confirmTs,
          clr: features.clr,
          dirMove: features.dirMove,
          forced,
          victimLiq: features.victimLiq,
        });
      this.lastConfirmTs = e.confirmTs;
    }
    const keepFrom = now - this.settings.referenceWindowMs;
    while (this.reference.length && this.reference[0].confirmTs < keepFrom)
      this.reference.shift();
    return decisions;
  }

  /** Mean poll-price high-low of the last 60 full minutes. */
  private typicalMinuteRange(now: number): number {
    const r = this.store.minuteRange(now - 61 * MINUTE_MS, now - MINUTE_MS);
    return r.length
      ? r.reduce((t, m) => t + (m.high - m.low), 0) / r.length
      : 0;
  }

  private snapshot(
    now: number,
    usable: Bucket[],
    regimes: Regime[],
    episodes: Episode[],
  ): V9EpisodeSnapshot {
    const lastIdx = usable.length - 1;
    const slope =
      regimes.find((r) => lastIdx >= r.a && lastIdx < r.b)?.slope ?? 0;
    const last = episodes.at(-1);
    const formingEp = last && !Number.isFinite(last.confirmTs) ? last : null;
    const f = formingEp ? episodeFeatures(usable, formingEp) : null;
    return {
      symbol: this.symbol,
      ts: now,
      oiPhase: slope < 0 ? "OI_FALLING" : slope > 0 ? "OI_RISING" : "OI_FLAT",
      oi: usable[lastIdx].oi,
      price: usable[lastIdx].price,
      forming:
        formingEp && f
          ? {
              start: formingEp.start,
              victim: formingEp.victim,
              parts: formingEp.parts,
              longUsd: formingEp.long,
              shortUsd: formingEp.short,
              oiDropPct: formingEp.oiDropPct,
              priceMovePct: formingEp.priceMovePct,
              dom: f.dom,
              dir: f.dir,
              exh: f.exh,
              clr: f.clr,
            }
          : null,
    };
  }
}

/** Where the confirming OI drop started: the minute of highest OI between
 *  the episode's last part and the confirmation (both already known). */
export function oiTurnTs(
  buckets: readonly Bucket[],
  e: Episode,
): number | null {
  if (!Number.isFinite(e.confirmTs)) return null;
  let best = -1;
  for (
    let i = Math.max(0, e.eIdx - 1);
    i < buckets.length && buckets[i].ts < e.confirmTs;
    i++
  ) {
    if (!(buckets[i].oi > 0)) continue;
    if (best < 0 || buckets[i].oi >= buckets[best].oi) best = i;
  }
  return best >= 0 ? buckets[best].ts : null;
}

export interface HourCandle {
  ts: number;
  high: number;
  low: number;
}

/** Complete UTC hours (start + 1h <= now) from per-minute lows/highs. */
export function hourCandles(
  minutes: ReadonlyArray<{ ts: number; low: number; high: number }>,
  now: number,
): HourCandle[] {
  const H = 3_600_000;
  const by = new Map<number, HourCandle>();
  for (const m of minutes) {
    const h = Math.floor(m.ts / H) * H;
    if (h + H > now) continue; // the current hour is not finished
    const c = by.get(h);
    if (!c) by.set(h, { ts: h, high: m.high, low: m.low });
    else {
      c.high = Math.max(c.high, m.high);
      c.low = Math.min(c.low, m.low);
    }
  }
  return [...by.values()].sort((a, b) => a.ts - b.ts);
}

/** The most recent CONFIRMED swing: a candle whose low (high) is strictly
 *  below (above) the k candles on each side; the k candles after it must
 *  already be complete. null when none. */
export function lastSwing(
  candles: readonly HourCandle[],
  kind: "LOW" | "HIGH",
  k: number,
): { ts: number; price: number } | null {
  for (let i = candles.length - 1 - k; i >= k; i--) {
    const v = kind === "LOW" ? candles[i].low : candles[i].high;
    let ok = true;
    for (let j = i - k; j <= i + k && ok; j++) {
      if (j === i) continue;
      const w = kind === "LOW" ? candles[j].low : candles[j].high;
      if (kind === "LOW" ? !(v < w) : !(v > w)) ok = false;
    }
    if (ok) return { ts: candles[i].ts, price: v };
  }
  return null;
}

const TREND_WARN_PCT = 2; // 24h move against the trade that earns a warning
const AGAINST_NOW_WARN_PCT = 0.1; // last 3 minutes against the trade

/** The three phases + warnings for the entry message. Only data up to `now`. */
export function buildV9Story(
  buckets: readonly Bucket[],
  e: Episode,
  victimLiqUsd: number,
  side: Victim,
  price: number,
  price3mAgo: number,
  now: number,
  selection: SelectionResult,
  forced: number,
  forcedMedian: number,
): V9Story {
  const victimOf = (b: Bucket): number =>
    e.victim === "LONG" ? b.long : b.short;
  const turnTs = oiTurnTs(buckets, e);
  const idxOf = (ts: number): number => buckets.findIndex((b) => b.ts === ts);
  const turnIdx = turnTs === null ? -1 : idxOf(turnTs);
  const lastBottom = turnIdx >= 0 ? turnIdx : Math.min(buckets.length, e.eIdx);
  let low = e.sIdx,
    big = e.sIdx;
  for (let i = e.sIdx; i < lastBottom; i++)
    if (
      buckets[i].oi > 0 &&
      !(buckets[low].oi > 0 && buckets[low].oi <= buckets[i].oi)
    )
      low = i;
  for (let i = e.sIdx; i < Math.min(buckets.length, e.eIdx); i++)
    if (victimOf(buckets[i]) > victimOf(buckets[big])) big = i;
  const B = buckets[low];
  const cleaning = {
    from: e.start,
    to: B.ts,
    liqUsd: victimLiqUsd,
    biggestTs: buckets[big].ts,
    biggestUsd: victimOf(buckets[big]),
    coins: e.startOi - B.oi,
    oiPct: e.startOi > 0 ? ((B.oi - e.startOi) / e.startOi) * 100 : NaN,
    priceFrom: e.startPrice,
    priceTo: B.price,
  };
  const T = turnIdx >= 0 ? buckets[turnIdx] : null;
  const accumulation =
    T && T.ts > B.ts
      ? {
          from: B.ts,
          to: T.ts,
          coins: T.oi - B.oi,
          oiPct: B.oi > 0 ? ((T.oi - B.oi) / B.oi) * 100 : NaN,
          priceFrom: B.price,
          priceTo: T.price,
        }
      : null;
  const confirmSide: Victim =
    e.confirmSide ?? (e.victim === "LONG" ? "SHORT" : "LONG");
  let turn: V9Story["turn"] = null;
  if (T) {
    let liq = 0,
      oiNow = T.oi;
    for (let i = turnIdx; i < buckets.length && buckets[i].ts <= now; i++) {
      liq += confirmSide === "LONG" ? buckets[i].long : buckets[i].short;
      if (buckets[i].oi > 0) oiNow = buckets[i].oi;
    }
    turn = {
      from: T.ts,
      to: e.confirmTs,
      coins: T.oi - oiNow,
      side: confirmSide,
      liqUsd: liq,
      priceFrom: T.price,
      priceTo: price,
    };
  }
  const warnings: V9Story["warnings"] = [];
  const typical = typicalLiquidationMinuteUsd(buckets as Bucket[]);
  if (turn && Number.isFinite(typical) && turn.liqUsd < typical)
    warnings.push({
      kind: "SMALL_CONFIRM",
      liqUsd: turn.liqUsd,
      typicalUsd: typical,
    });
  if (price > 0 && price3mAgo > 0) {
    const mv = ((price - price3mAgo) / price3mAgo) * 100;
    if (
      side === "LONG" ? mv <= -AGAINST_NOW_WARN_PCT : mv >= AGAINST_NOW_WARN_PCT
    )
      warnings.push({ kind: "AGAINST_NOW", movePct: mv });
  }
  const dayAgo = buckets.find(
    (b) => b.ts >= now - 24 * 3_600_000 && b.price > 0,
  );
  if (dayAgo && price > 0 && now - dayAgo.ts >= 20 * 3_600_000) {
    const ch = ((price - dayAgo.price) / dayAgo.price) * 100;
    if (side === "LONG" ? ch <= -TREND_WARN_PCT : ch >= TREND_WARN_PCT)
      warnings.push({ kind: "AGAINST_TREND", changePct: ch });
  }
  if (
    Number.isFinite(forced) &&
    Number.isFinite(forcedMedian) &&
    forced < forcedMedian
  )
    warnings.push({
      kind: "NOT_FORCED",
      forcedPct: forced * 100,
      medianPct: forcedMedian * 100,
    });
  const checks = Object.values(selection.checks);
  return {
    victim: e.victim,
    cleaning,
    accumulation,
    turn,
    checksPassed: checks.filter(Boolean).length,
    checksTotal: checks.length,
    warnings,
  };
}

/** Share of the cleaning's closed positions that were FORCED: victim
 *  liquidations $ / (OI drop in coins x price). NaN when not measurable. */
export function forcedShare(e: Episode, victimLiqUsd: number): number {
  const dropUsd = (e.startOi - e.minOi) * e.endPrice;
  return dropUsd > 0 ? victimLiqUsd / dropUsd : NaN;
}

/** During the accumulation (lowest OI before the turn -> the OI turn) the
 *  price kept going the cleaning's way: lower for LONG victims, higher for
 *  SHORT victims -- the new positions were opened AGAINST our coming trade. */
export function accumulationAgainst(
  buckets: readonly Bucket[],
  e: Episode,
): boolean {
  const turnTs = oiTurnTs(buckets, e);
  if (turnTs === null) return false;
  let low = -1,
    turn = -1;
  for (let i = e.sIdx; i < buckets.length && buckets[i].ts <= turnTs; i++) {
    if (!(buckets[i].oi > 0)) continue;
    if (buckets[i].ts === turnTs) {
      turn = i;
      break;
    }
    if (low < 0 || buckets[i].oi < buckets[low].oi) low = i;
  }
  if (low < 0 || turn < 0) return false;
  const a = buckets[low].price,
    b = buckets[turn].price;
  if (!(a > 0) || !(b > 0)) return false;
  return e.victim === "LONG" ? b < a : b > a;
}

/** Since the OI turn (where the confirming OI drop started) the price moved
 *  OUR way: up for a BUY (side LONG), down for a SELL. Unknown turn = false. */
export function turnDirectionOk(
  buckets: readonly Bucket[],
  e: Episode,
  side: Victim,
  price: number,
): boolean {
  const turnTs = oiTurnTs(buckets, e);
  const turnPrice =
    turnTs === null
      ? NaN
      : (buckets.find((b) => b.ts === turnTs)?.price ?? NaN);
  return (
    Number.isFinite(turnPrice) &&
    price > 0 &&
    (side === "LONG" ? price > turnPrice : price < turnPrice)
  );
}

/** Share of the positions closed in the cleaning that were re-opened before
 *  the confirming OI drop: (OI at the turn - lowest OI before it) /
 *  (episode start OI - episode OI bottom). Only data up to the confirmation.
 *  null when it cannot be measured. */
export function regrowShare(
  buckets: readonly Bucket[],
  e: Episode,
): number | null {
  const turnTs = oiTurnTs(buckets, e);
  if (turnTs === null) return null;
  const drop = e.startOi - e.minOi;
  if (!(drop > 0)) return null;
  let low = Infinity,
    turnOi = NaN;
  for (let i = e.sIdx; i < buckets.length && buckets[i].ts <= turnTs; i++) {
    const oi = buckets[i].oi;
    if (!(oi > 0)) continue;
    if (buckets[i].ts === turnTs) {
      turnOi = oi;
      break;
    }
    low = Math.min(low, oi);
  }
  if (!Number.isFinite(low) || !(turnOi > 0)) return null;
  return Math.max(0, turnOi - low) / drop;
}

const ACCUM_WINDOW = 30; // minutes

/** Biggest OI rise (%) inside any 30-minute window of [from, to] (bucket indexes). */
function maxWindowRisePct(
  buckets: readonly Bucket[],
  from: number,
  to: number,
): number {
  let best = 0;
  for (let i = from + 1; i <= to; i++) {
    const cur = buckets[i].oi;
    if (!(cur > 0)) continue;
    let low = Infinity;
    for (let j = Math.max(from, i - ACCUM_WINDOW); j < i; j++)
      if (buckets[j].oi > 0) low = Math.min(low, buckets[j].oi);
    if (Number.isFinite(low)) best = Math.max(best, ((cur - low) / low) * 100);
  }
  return best;
}

/** True when the accumulation after the episode (OI bottom -> OI peak before
 *  the confirmation) contains a 30-minute OI rise at least at the
 *  `percentile` of the coin's 30-minute OI rises before the confirmation. */
export function sharpAccumulation(
  buckets: readonly Bucket[],
  e: Episode,
  percentile: number,
): boolean {
  const turnTs = oiTurnTs(buckets, e);
  if (turnTs === null) return false;
  let bottom = -1,
    peak = -1;
  for (let i = e.sIdx; i < buckets.length && buckets[i].ts <= turnTs; i++) {
    if (!(buckets[i].oi > 0)) continue;
    if (i < e.eIdx && (bottom < 0 || buckets[i].oi < buckets[bottom].oi))
      bottom = i;
    if (buckets[i].ts === turnTs) peak = i;
  }
  if (bottom < 0 || peak <= bottom) return false;
  const rise = maxWindowRisePct(buckets, bottom, peak);
  // the coin's normal 30-minute OI rises, only from data before the confirmation
  const rises: number[] = [];
  for (
    let i = ACCUM_WINDOW;
    i < buckets.length && buckets[i].ts < e.confirmTs;
    i += 5
  ) {
    const a = buckets[i - ACCUM_WINDOW].oi,
      b = buckets[i].oi;
    if (a > 0 && b > a) rises.push(((b - a) / a) * 100);
  }
  if (rises.length < 20) return false;
  rises.sort((x, y) => x - y);
  const threshold =
    rises[
      Math.min(rises.length - 1, Math.floor((percentile / 100) * rises.length))
    ];
  return rise >= threshold;
}
