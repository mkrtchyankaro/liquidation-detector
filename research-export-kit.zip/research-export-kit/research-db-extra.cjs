// READ-ONLY DB export (research). Uses ONLY: listCollections, listIndexes, estimatedDocumentCount, findOne, find (cursor) - no write call exists in this file.
// Connection settings are the project's own: <project>/.env -> MONGO_URI and MONGO_OWN_DB (default "liquidation_detector"), as in src/config/env.ts.
// Usage: node research-db-extra.cjs <project_dir> <out_dir> <from_iso_utc> <to_iso_utc>     (window [from, to) in UTC)
// Writes: minute_bars.csv (every minute bar of the 25 coins in the window, all fields, missing minutes simply absent - never zero-filled)
//         db_inventory.json (collections, sizes, indexes, field names of one sample doc, per-symbol first/last time in the window)
"use strict";
const path = require("path");
const fs = require("fs");
const [PROJECT, OUT, FROM, TO] = process.argv.slice(2);
if (!PROJECT || !OUT || !FROM || !TO) { console.error("usage: node research-db-extra.cjs <project_dir> <out_dir> <from_iso> <to_iso>"); process.exit(2); }
require(path.join(PROJECT, "node_modules", "dotenv")).config({ path: path.join(PROJECT, ".env") });
const { MongoClient } = require(path.join(PROJECT, "node_modules", "mongodb"));
const COINS = ["ADA","ALGO","AVAX","BCH","BNB","BTC","DOGE","DOT","ENA","ETH","HBAR","HYPE","LINK","LTC","NEAR","ONDO","SOL","STRK","SUI","UNI","WLD","XLM","XRP","XTZ","ZEC"].map((c) => c + "USDT");
const from = new Date(FROM + "Z"), to = new Date(TO + "Z");
const iso = (d) => new Date(d).toISOString().slice(0, 19).replace("T", " ");
const cell = (v) => (v === null || v === undefined ? "" : String(v));
const typeOf = (v) => (v === null ? "null" : v instanceof Date ? "Date" : Array.isArray(v) ? "array" : typeof v);
(async () => {
  const uri = process.env.MONGO_URI;
  if (!uri) { console.error("MONGO_URI is not set in " + path.join(PROJECT, ".env")); process.exit(3); }
  const client = new MongoClient(uri, { readPreference: "secondaryPreferred", appName: "research-export-readonly" });
  await client.connect();
  const db = client.db(process.env.MONGO_OWN_DB || "liquidation_detector");
  const inv = { db_name: db.databaseName, window_utc: { from: iso(from), to: iso(to) }, collections: [], per_symbol: {} };
  try {
    // ---- inventory (schema inspection: field NAMES and TYPES only, values are not written)
    for (const c of (await db.listCollections({}, { nameOnly: true }).toArray()).map((x) => x.name).sort()) {
      const col = db.collection(c); const rec = { name: c };
      try { rec.estimated_docs = await col.estimatedDocumentCount(); } catch (e) { rec.estimated_docs = "error: " + e.message; }
      try { rec.indexes = (await col.listIndexes().toArray()).map((i) => ({ key: i.key, ttl_seconds: i.expireAfterSeconds })); } catch (e) { rec.indexes = []; }
      if (/liq|minute|bar|oi|backup|archive|snapshot|aggregate/i.test(c)) {
        try { const s = await col.findOne({}, { projection: { _id: 0 } }); rec.sample_fields = s ? Object.fromEntries(Object.entries(s).map(([k, v]) => [k, typeOf(v)])) : null; } catch (e) { rec.sample_fields = "error"; }
      }
      inv.collections.push(rec);
    }
    // ---- per symbol first / last record inside the window (indexed queries only)
    const tf = { minute_bars: ["ts", from, to], liq_raw_events: ["timestamp", from.getTime(), to.getTime()], oi_second_observations: ["timestamp", from, to] };   // minute_bars.ts and oi_second_observations.timestamp are Dates, liq_raw_events.timestamp is epoch ms (project schema)
    const names = new Set(inv.collections.map((x) => x.name));
    for (const sym of COINS) {
      inv.per_symbol[sym] = {};
      for (const [c, [f, a, b]] of Object.entries(tf)) {
        if (!names.has(c)) { inv.per_symbol[sym][c] = "collection not found"; continue; }
        const q = { symbol: sym, [f]: { $gte: a, $lt: b } };
        const first = await db.collection(c).find(q, { projection: { _id: 0, [f]: 1 } }).sort({ [f]: 1 }).limit(1).toArray();
        const last = await db.collection(c).find(q, { projection: { _id: 0, [f]: 1 } }).sort({ [f]: -1 }).limit(1).toArray();
        inv.per_symbol[sym][c] = { first: first[0] ? iso(first[0][f]) : null, last: last[0] ? iso(last[0][f]) : null };
      }
    }
    // ---- minute_bars dump (streamed, symbol by symbol)
    const COLS = ["symbol", "minute_utc", "open", "high", "low", "close", "oiFirst", "oiLast", "oiMin", "oiMax", "polls", "longLiqUsd", "shortLiqUsd", "longLiqCount", "shortLiqCount"];
    const w = fs.createWriteStream(path.join(OUT, "minute_bars.csv")); w.write(COLS.join(",") + "\n");
    let total = 0;
    for (const sym of COINS) {
      let n = 0;
      const cur = db.collection("minute_bars").find({ symbol: sym, ts: { $gte: from, $lt: to } }, { projection: { _id: 0 } }).sort({ ts: 1 });
      for await (const b of cur) {
        const row = [sym, iso(b.ts).slice(0, 16), b.open, b.high, b.low, b.close, b.oiFirst, b.oiLast, b.oiMin, b.oiMax, b.polls, b.longLiqUsd, b.shortLiqUsd, b.longLiqCount, b.shortLiqCount].map(cell).join(",");
        if (!w.write(row + "\n")) await new Promise((r) => w.once("drain", r));
        n++;
      }
      inv.per_symbol[sym].minute_bars_rows_exported = n; total += n;
    }
    await new Promise((r) => w.end(r));
    inv.minute_bars_rows_exported = total;
  } finally {
    await client.close();
  }
  fs.writeFileSync(path.join(OUT, "db_inventory.json"), JSON.stringify(inv, null, 1));
  console.log(`db extra: ${inv.collections.length} collections inventoried, ${inv.minute_bars_rows_exported} minute bars exported`);
})().catch((e) => { console.error("db extra failed: " + (e && e.message ? e.message : e)); process.exit(1); });
