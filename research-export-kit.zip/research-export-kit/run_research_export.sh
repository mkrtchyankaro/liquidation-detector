#!/usr/bin/env bash
# ONE-COMMAND RESEARCH EXPORT (read-only).  Usage:  bash research-export-kit/run_research_export.sh [project_dir]
#   1. src/tools/research-1h-export.ts (the project's own, UNCHANGED) -> Binance 1h klines + OI 5m + our DB hourly liquidation, last 14 days
#      up to the last CLOSED hour. It is run from a fresh folder, so the old reports/research-1h export is NOT overwritten.
#   2. research-db-extra.cjs -> minute_bars rows + collection inventory (find / list only).
#   3. research_pipeline.py  -> old finder (sha-checked, unchanged) + end rule + liquidation enrichment + hourly details + checks + ZIP.
# Writes only into  <project>/reports/research-export-<UTC stamp>/  and  <same>.zip. Never touches the DB, collector, bot, V11 or old reports.
set -euo pipefail
PROJECT="$(cd "${1:-$PWD}" && pwd)"
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
EXP="$PROJECT/reports/research-export-$STAMP"
fail() { echo "STOP: $*" >&2; exit 1; }
[ -f "$PROJECT/src/tools/research-1h-export.ts" ] || fail "missing $PROJECT/src/tools/research-1h-export.ts (the existing downloader). Nothing was run."
[ -x "$PROJECT/node_modules/.bin/tsx" ] || fail "missing $PROJECT/node_modules/.bin/tsx (run 'npm ci' in the project first). Nothing was run."
[ -d "$PROJECT/node_modules/mongodb" ] && [ -d "$PROJECT/node_modules/dotenv" ] || fail "project node_modules has no mongodb/dotenv."
[ -f "$PROJECT/.env" ] || fail "missing $PROJECT/.env (MONGO_URI). Nothing was run."
command -v node >/dev/null || fail "node not found"
command -v python3 >/dev/null || fail "python3 not found (needed for the old finder). Install python3 (standard library only)."
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' || fail "python3 >= 3.8 required"
for f in research_pipeline.py research-db-extra.cjs finder/oi_cascade_research_v2.py finder/load.py; do [ -f "$KIT/$f" ] || fail "kit file missing: $f"; done
[ -e "$EXP" ] && fail "$EXP already exists (refusing to overwrite)"
mkdir -p "$EXP/tmp_downloader" "$EXP/raw"
echo "== 1/3 downloader (existing research-1h-export.ts, 14 days to the last closed hour) =="
( cd "$EXP/tmp_downloader" && DOTENV_CONFIG_PATH="$PROJECT/.env" "$PROJECT/node_modules/.bin/tsx" --tsconfig "$PROJECT/tsconfig.json" "$PROJECT/src/tools/research-1h-export.ts" --days 14 )
mv "$EXP/tmp_downloader/reports/research-1h/"* "$EXP/raw/"
rm -rf "$EXP/tmp_downloader"
read -r FROM TO < <(python3 "$KIT/research_pipeline.py" window "$EXP/raw/all_1h.csv")
echo "== 2/3 DB minute bars + inventory, window [$FROM, $TO) UTC =="
node "$KIT/research-db-extra.cjs" "$PROJECT" "$EXP/raw" "$FROM" "$TO"
echo "== 3/3 old finder + end rule + liquidation enrichment + checks =="
set +e
PROJECT_DIR="$PROJECT" python3 "$KIT/research_pipeline.py" run "$EXP" "$KIT" | tee "$EXP/pipeline_log.txt"
RC=${PIPESTATUS[0]}
set -e
ZIP="$EXP.zip"
echo
[ "$RC" -eq 0 ] && echo "ALL CHECKS PASSED" || echo "CHECKS FAILED - see export_manifest.json inside the ZIP (the ZIP is still written for review)"
echo "ZIP: $ZIP  ($(du -h "$ZIP" | cut -f1))"
echo "Download from your computer:  scp <user>@<server>:$ZIP ."
exit "$RC"
