RESEARCH EXPORT KIT (read-only).

RUN (in the project folder on the server, after unzipping this kit there):
    bash research-export-kit/run_research_export.sh .

WHAT IT DOES
1. Runs the project's own src/tools/research-1h-export.ts, unchanged.
   - Data: Binance 1h klines, Binance OI 5m history, and our DB hourly liquidations and liq_raw_events.
   - Window: the last 14 days, up to the last closed hour (UTC).
   - It runs inside a new folder, so the existing reports/research-1h export is not overwritten.
2. research-db-extra.cjs exports every minute_bars row in the same window. It also writes a collection inventory: names, sizes, indexes,
   field names and types, and the first/last record per coin. It uses the project's .env (MONGO_URI, MONGO_OWN_DB) and only find/list calls.
3. research_pipeline.py does the rest:
   - It runs the OLD finder: finder/oi_cascade_research_v2.py = restored hfinder3, sha256 checked; only its two path lines are replaced in a
     temporary copy.
   - The finder runs twice, as a determinism check.
   - It then applies the end rule (>= 95 % -> end on that close; > 80 % and < 95 % -> end on exactly one next closed candle; not closed yet -> PENDING).
   - It adds liquidation columns: S->X, X->end, end candle, 1..4 candles after the end, 1..4 candles before the end.
   - It writes hourly details from S-4 h to end+4 h, the coverage table, the checks and the manifest, and builds the ZIP.

OUTPUT
reports/research-export-<UTC stamp>/ and reports/research-export-<UTC stamp>.zip.

ZIP root:
- all_1h.csv
- movements.csv
- movements_with_end.csv
- movements_with_liquidations.csv
- cascade_hourly_details.csv
- liquidation_coverage.csv
- export_manifest.json

Folders:
- finder/: level files and finder input
- raw/: liq_events.csv, minute_bars.csv, db_inventory.json
- code/: every script used, with sha256 in the manifest

Missing liquidation data is left EMPTY with status DATA_MISSING. It is never written as 0.
Exit code 0 = all checks passed. Exit code 1 = a check failed: the manifest lists it, and the ZIP is still written.
The script stops before doing anything if the downloader, node_modules, .env or python3 (>= 3.8) is missing.
