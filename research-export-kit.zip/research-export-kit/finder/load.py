"""Loads the research 1H export (all_1h.csv from src/tools/research-1h-export.ts; works for --days 14 or --days 30).
Uses ONLY price (Binance 1h klines) and Binance OI (openInterestHist 5m -> oi_open = OI at the hour start, oi_close = at the hour end,
oi_high / oi_low = max / min of the 13 five-minute points of the hour). Liquidation columns are ignored entirely.
Checks: every hour present, price and OI on the same hour key, oi_open(h) == oi_close(h-1), oi_low <= open/close <= oi_high."""
import csv, sys, datetime as dt, collections as C
H = 3600000
P = lambda s: int(dt.datetime.strptime(s, '%Y-%m-%d %H:%M').replace(tzinfo=dt.timezone.utc).timestamp() * 1000)
U = lambda t: dt.datetime.fromtimestamp(t / 1000, dt.timezone.utc).strftime('%Y-%m-%d %H:%M')
def load(path):
    D = C.defaultdict(list)
    f = lambda x: float(x) if x not in ('', None) else None
    for r in csv.DictReader(open(path, newline='')):
        D[r['symbol']].append(dict(t=P(r['open_time_utc']), o=f(r['open']), h=f(r['high']), l=f(r['low']), c=f(r['close']),
                                   oo=f(r['oi_open']), oc=f(r['oi_close']), oh=f(r['oi_high']), ol=f(r['oi_low'])))
    for s in D: D[s].sort(key=lambda b: b['t'])
    return dict(D)
def check(D, out):
    lines = []
    for s, B in sorted(D.items()):
        gaps = sum(1 for a, b in zip(B, B[1:]) if b['t'] - a['t'] != H)
        miss = sum(1 for b in B if None in (b['o'], b['c'], b['oo'], b['oc'], b['oh'], b['ol']))
        cont = max((abs(b['oo'] / a['oc'] - 1) for a, b in zip(B, B[1:]) if a['oc'] and b['oo']), default=0)
        bad = sum(1 for b in B if b['ol'] is not None and not (b['ol'] <= min(b['oo'], b['oc']) + 1e-9 and max(b['oo'], b['oc']) <= b['oh'] + 1e-9))
        lines.append(f"{s:9s} hours {len(B)} {U(B[0]['t'])} -> {U(B[-1]['t'])} | gaps {gaps} | missing values {miss} | max |oi_open - prev oi_close| {100*cont:.4f} % | OI OHLC violations {bad}")
    open(out, 'w').write(__doc__ + '\n' + '\n'.join(lines) + '\n'); print('\n'.join(lines))
if __name__ == '__main__':
    check(load(sys.argv[1]), sys.argv[2])
