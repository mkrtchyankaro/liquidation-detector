"""OI CASCADE RESEARCH v2 - REPAIRED (two fixes, no rule change):
  FIX 1 (level timing): each closed candle first runs the line test / registers or continues a movement, THEN updates the returns of all
         movements with that same close -> a level reached on the detecting candle gets that candle's close.
  FIX 2 (joined moves): the start is always found by walking left FROM X (not from the crossing), so every opposite group between the
         start and X is examined with the same inside/boundary rule; a continuation (X moves) is accepted only if the walk from the new X
         reaches the same start. A line that crosses a body at or before the start is past OI0 of that movement and never opens a new one.
  Exact ties (an opposite group ending exactly at the open) are marked BOUNDARY_TIE for manual review.
ORIGINAL DESCRIPTION (unchanged rules) - OI CASCADE RESEARCH - corrected rules (research only; V11 / live / production / TP-SL / viewer untouched).
Data: real Binance 1 h price + OI, 25 USDT-M coins, 2026-09-28 13:00 -> 2026-10-12 13:00 UTC close. No earlier history is available here:
a start that needs it is START_UNKNOWN. No time limits. Every decision uses only candles closed at that moment.

OI MOVEMENT (per closed candle t):
  green t -> return of an OI decline (looks for red bodies); red t -> return of an OI rise (green bodies).
  crossing = nearest earlier opposite-colour OI body containing the OI close of t (only locates the move, it is not the start);
  X = extreme OI close from the crossing to t-1;
  START: walk left from the crossing over the move's candles. A group of opposite candles whose level range stays inside the body of the
    move candle just before it is a small inside move and does NOT end the movement; a group that reaches that candle's open ends it
    (a separate move). The passed inside groups and the boundary group are written out (start_confidence), so every start can be
    re-checked by hand. Walk reaching the first candle of the data -> START_UNKNOWN.
  OI0 frozen when the movement is first found; X moves only while the move continues before 100 % (same start re-detected).
  RETURN % = 100 x (L - X) / (OI0 - X) [decline] or 100 x (X - L) / (X - OI0) [rise]. Levels 80 85 90 93 95 100 103 105 107 110, first close.
  OPEN/CLOSE control on level closes >= 100 %: is the OI open still inside a body of this move, is the close beyond OI0. Never moves OI0.
  DEPTH: |X - OI0| absolute, %, and / median |hourly OI change| of the hours before X -> DEPTH_UNDECIDED (no cut-off; quartiles descriptive).

PRICE MARKET at a level close T (closes S..T only; S = OI start candle):
  UP   : price at X > price at S, price at T > price at S, the lowest close of S..T comes no later than X and before the highest close;
  DOWN : the mirror;  MIXED otherwise (reason written).  Single small dips do not decide: only the order of the structure's lowest and
  highest closes and their relation to the OI phase (S..X) count. UP -> SHORT, DOWN -> LONG, MIXED -> NO SIGNAL. OI direction never decides.
  The largest counter swing inside S..T (as % of the S..T price range) is recorded for manual checking only.
FOLLOW-UP prices / OI (0..24 h) are recorded for evaluation only and never used to find or classify anything."""
import sys, os, csv, json, statistics as st, collections as C
sys.path.append('/home/claude/v11/out/sim_src')
from load import load, U, H
D = load(sys.argv[1]); OUT = '/home/claude/v11/out/cyc/hfinder3'; os.makedirs(f'{OUT}/charts', exist_ok=True)
LEVELS = (80, 85, 90, 93, 95, 100, 103, 105, 107, 110); FH = (0, 1, 2, 3, 4, 6, 8, 12, 24)
def col(b): return 1 if b['oc'] > b['oo'] else -1 if b['oc'] < b['oo'] else 0
def cross(B, t, L, want):
    for j in range(t - 1, -1, -1):
        b = B[j]
        if col(b) == want and min(b['oo'], b['oc']) <= L <= max(b['oo'], b['oc']): return j
    return None
def walk(B, j, mv):
    oc = lambda i: B[i]['oc']; k = j; best = j - 1; groups = []
    while k >= 1:
        if col(B[k]) != -mv:
            if mv * (oc(k - 1) - oc(best)) < 0: best = k - 1
            k -= 1; continue
        m = k
        while m >= 1 and col(B[m]) == -mv: m -= 1
        if m < 1: return None, groups
        top = max((oc(i) for i in range(m + 1, k + 1)), key=lambda v: -mv * v); po = B[m]['oo']
        inside = -mv * (top - po) < 0
        groups.append(dict(first=m + 1, last=k, top=top, prev=m, prev_open=po, prev_close=B[m]['oc'], inside=inside, margin=abs(po - top)))
        if not inside: return best, groups
        k = m
    return None, groups
def base_oi(B, t):
    xs = [abs(B[i]['oc'] - B[i]['oo']) for i in range(max(0, t - 720), t)]
    return st.median(xs) if len(xs) >= 24 else None
tv = lambda B, i: U(B[i]['t'])[:16]; cl = lambda B, i: U(B[i]['t'] + H)[:16]
def market(B, S, X, T):
    p = [B[i]['c'] for i in range(S, T + 1)]; pS, pX, pT = B[S]['c'], B[X]['c'], B[T]['c']
    il = S + min(range(len(p)), key=lambda i: (p[i], i)); ih = S + max(range(len(p)), key=lambda i: (p[i], -i))
    rng = max(p) - min(p); cs = 0.0                                   # largest counter swing against the S->T direction (manual check only)
    d = 1 if pT >= pS else -1; ext = p[0]
    for v in p:
        if d * (v - ext) > 0: ext = v
        cs = max(cs, d * (ext - v))
    info = dict(lowest=f'{cl(B, il)} {B[il]["c"]:.6g}', highest=f'{cl(B, ih)} {B[ih]["c"]:.6g}', counter_swing_pct_of_range=round(100 * cs / rng, 1) if rng else 0)
    if pX > pS and pT > pS and il <= X and il < ih: return 'UP', 'price rose during the OI phase, the lowest close is before the highest and inside the OI phase, signal price above start', info
    if pX < pS and pT < pS and ih <= X and ih < il: return 'DOWN', 'price fell during the OI phase, the highest close is before the lowest and inside the OI phase, signal price below start', info
    r = []
    if (pX - pS) * (pT - pS) <= 0: r.append('signal price on the other side of the start than during the OI phase')
    if pX > pS and not (il <= X and il < ih): r.append('lowest close of the structure comes after the OI phase or after the highest close')
    if pX < pS and not (ih <= X and ih < il): r.append('highest close of the structure comes after the OI phase or after the lowest close')
    if pX == pS: r.append('no price change during the OI phase')
    return 'MIXED', '; '.join(r) or 'structure not one-directional', info
# ------------------------------------------------------------------ scan (repaired)
MOV = []; CNT = C.Counter()
for sym, B in D.items():
    coin = sym[:-4]; reg = {}
    for t in range(1, len(B)):
        b = B[t]; c = col(b); L = b['oc']
        # ---- 1) line test and registration on this close
        if c == 0: CNT['flat candle'] += 1
        else:
            mv = -c; j = cross(B, t, L, mv)
            if j is None: CNT['no crossing in the available history'] += 1
            else:
                CNT['crossing found'] += 1
                Xi = min(range(j, t), key=lambda i: B[i]['oc']) if mv < 0 else max(range(j, t), key=lambda i: B[i]['oc'])
                S, groups = walk(B, Xi, mv)                                   # FIX 2: walk from X over the whole S..X structure
                key = (mv, S if S is not None else ('UNK', Xi))
                if S is not None and j <= S: CNT['line crosses a body at/before the start (past OI0 of this movement)'] += 1
                owner = [M for M in reg.values() if M['mv'] == mv and M['X'] == Xi and M['state'] != 'ended' and M['key'] != key]
                if owner: CNT['CONFLICT: another movement owns this X (kept, logged)'] += 1
                elif key in reg:
                    M = reg[key]
                    if M['state'] != 'ended':
                        if M['X'] != Xi and mv * (B[Xi]['oc'] - B[M['X']]['oc']) > 0:   # deeper extreme reached from the same start: continuation
                            M['X'] = Xi; M['lv'] = {}; M['max_r'] = 0; M['xmoves'].append(cl(B, Xi)); M.pop('done', None); M['groups'] = groups
                        M['state'] = 'active'
                else:
                    reg[key] = dict(sym=sym, coin=coin, key=key, mv=mv, S=S, X=Xi, groups=groups, first=t, j=j, lv={}, max_r=0, state='active', xmoves=[], last_t=None)
        # ---- 2) update all movements with this close (FIX 1: after registration)
        for M in reg.values():
            if M['state'] == 'ended': continue
            X = M['X']; mvm = M['mv']
            if mvm * (L - B[X]['oc']) > 0:
                M['state'] = 'ended' if M.get('done') else 'suspended'; continue
            if M['state'] != 'active' or t <= X or M['S'] is None: continue
            r = 100 * (L - B[X]['oc']) / (B[M['S']]['oc'] - B[X]['oc']); M['max_r'] = max(M['max_r'], r); M['last_t'] = t
            for lv in LEVELS:
                if r >= lv and lv not in M['lv']: M['lv'][lv] = t
            if r >= 100: M['done'] = True
    MOV += [M for M in reg.values()]
# ------------------------------------------------------------------ tables
MOV.sort(key=lambda M: (M['coin'], M['X']))
mrows, lrows, frows, prows = [], [], [], []
for n, M in enumerate(MOV, 1):
    B = D[M['sym']]; S, X, mv = M['S'], M['X'], M['mv']; mid = f'{M["coin"]}-{n:05d}'; M['id'] = mid
    passed = [g for g in M['groups'] if g['inside']]; bnd = [g for g in M['groups'] if not g['inside']]
    conf = ('CLEAN: no opposite candle inside the move' if not passed else f'PASSED {len(passed)} inside group(s): ' + ' | '.join(
        f'TV {tv(B, g["first"])[5:]}..{tv(B, g["last"])[11:]} reached {g["top"]:,.6g}, stayed inside body of TV {tv(B, g["prev"])[5:]} ({g["prev_open"]:,.6g}->{g["prev_close"]:,.6g})' for g in passed))
    if bnd and bnd[0]['margin'] == 0: conf = 'BOUNDARY_TIE (group ends exactly at the open) - ' + conf
    if bnd: g = bnd[0]; conf += f' || boundary: group TV {tv(B, g["first"])[5:]}..{tv(B, g["last"])[11:]} reached {g["top"]:,.6g}, beyond open {g["prev_open"]:,.6g} of TV {tv(B, g["prev"])[5:]} by {g["margin"]:,.6g}'
    row = dict(coin=M['coin'], movement_id=mid, oi_direction='UP' if mv > 0 else 'DOWN', start_status='START_UNKNOWN' if S is None else 'FOUND', start_confidence=conf if S is not None else 'walk reached the first candle of the data',
               extreme_UTC_open=tv(B, X), extreme_UTC_close=cl(B, X), extreme_OI=B[X]['oc'], extreme_price=B[X]['c'], X_moves=';'.join(M['xmoves']), first_found_close=cl(B, M['first']),
               crossing_UTC_open=tv(B, M['j']), max_return_pct=round(M['max_r'], 1))
    if S is not None:
        d = abs(B[X]['oc'] - B[S]['oc']); bo = base_oi(B, X)
        row.update(start_UTC_open=tv(B, S), start_UTC_close=cl(B, S), start_OI_open=B[S]['oo'], start_OI_close=B[S]['oc'], start_price_open=B[S]['o'], start_price_close=B[S]['c'],
                   OI0=B[S]['oc'], depth_abs=d, depth_pct=100 * d / B[S]['oc'], depth_hours=X - S, depth_rel_normal=(d / bo) if bo else '')
        T100 = M['lv'].get(100) or (max(M['lv'].values()) if M['lv'] else None)
        if T100:
            mk, why, info = market(B, S, X, T100)
            row.update(market_structure_start=cl(B, S), market_structure_end=cl(B, T100), market_direction=mk, market_direction_reason=why + f' (evaluated at the {"100 %" if 100 in M["lv"] else "highest reached level"} close)',
                       structure_lowest=info['lowest'], structure_highest=info['highest'], counter_swing_pct_of_range=info['counter_swing_pct_of_range'])
    mrows.append(row); M['row'] = row
dq = sorted(r['depth_rel_normal'] for r in mrows if isinstance(r.get('depth_rel_normal'), float)); qc = [dq[int(p * (len(dq) - 1))] for p in (.25, .5, .75)]
for r in mrows:
    v = r.get('depth_rel_normal'); r['depth_status'] = 'DEPTH_UNDECIDED'
    r['depth_quartile'] = '' if not isinstance(v, float) else 'Q1' if v < qc[0] else 'Q2' if v < qc[1] else 'Q3' if v < qc[2] else 'Q4'
for M in MOV:
    B = D[M['sym']]; S, X, mv = M['S'], M['X'], M['mv']; r = M['row']
    if S is None: continue
    t80 = M['lv'].get(80); prog = dict(movement_id=M['id'], coin=M['coin'], oi_direction=r['oi_direction'], depth_quartile=r['depth_quartile'], max_return_observed=round(M['max_r'], 1),
                                       followup_end=cl(B, M['last_t']) if M['last_t'] else '')
    for lv in LEVELS:
        T = M['lv'].get(lv)
        e = dict(coin=M['coin'], movement_id=M['id'], return_level=lv, reached='TRUE' if T else 'FALSE', OI0=B[S]['oc'], OI_extreme=B[X]['oc'], depth_status='DEPTH_UNDECIDED', depth_quartile=r['depth_quartile'])
        if T:
            mk, why, info = market(B, S, X, T); side = 'SHORT' if mk == 'UP' else 'LONG' if mk == 'DOWN' else 'NO SIGNAL'
            q = B[T]; ret = 100 * (q['oc'] - B[X]['oc']) / (B[S]['oc'] - B[X]['oc'])
            oc_ctrl = ''
            if lv >= 100:
                inside = any(col(B[j]) == mv and min(B[j]['oo'], B[j]['oc']) <= q['oo'] <= max(B[j]['oo'], B[j]['oc']) for j in range(S + 1, X + 1))
                beyond = (q['oc'] - B[S]['oc']) * (-mv) >= 0
                oc_ctrl = f'open {"inside a body of this move" if inside else "not inside this move"}; close {"beyond OI0" if beyond else "not beyond OI0"}'
            e.update(first_reach_UTC_open=tv(B, T), first_reach_UTC_close=cl(B, T), actual_return_pct_at_close=round(ret, 2), OI_open_at_signal=q['oo'], OI_close_at_signal=q['oc'],
                     price_open_at_signal=q['o'], price_close_at_signal=q['c'], price_high_at_signal=q['h'], price_low_at_signal=q['l'], market_direction=mk, proposed_side=side,
                     rejection_reason='' if side != 'NO SIGNAL' else 'market MIXED: ' + why, hours_from_extreme=T - X, hours_from_80=(T - t80) if t80 else '', open_close_control=oc_ctrl)
            dd = -1 if side == 'SHORT' else 1 if side == 'LONG' else 0
            for h in FH:
                f_ = dict(coin=M['coin'], movement_id=M['id'], return_level=lv, signal_UTC_close=cl(B, T), followup_hours=h, proposed_side=side, price_at_signal=q['c'], OI_at_signal=q['oc'])
                if T + h < len(B):
                    g = B[T + h]
                    f_.update(followup_UTC_close=cl(B, T + h), price_at_followup=g['c'], price_change_pct=round(100 * (g['c'] / q['c'] - 1), 4), OI_at_followup=g['oc'],
                              OI_change_pct=round(100 * (g['oc'] / q['oc'] - 1), 4), OI_return_pct_at_followup=round(100 * (g['oc'] - B[X]['oc']) / (B[S]['oc'] - B[X]['oc']), 2),
                              directional_price_return_pct=round(dd * 100 * (g['c'] / q['c'] - 1), 4) if dd else '', data_available='TRUE')
                    if h > 0:
                        hi_ = max(B[i]['h'] for i in range(T + 1, T + h + 1)); lo_ = min(B[i]['l'] for i in range(T + 1, T + h + 1))
                        f_.update(max_high=hi_, min_low=lo_, max_up_pct=round(100 * (hi_ / q['c'] - 1), 4), max_down_pct=round(100 * (lo_ / q['c'] - 1), 4))
                        if dd: f_.update(MFE_pct=round(100 * ((hi_ - q['c']) / q['c'] if dd > 0 else (q['c'] - lo_) / q['c']), 4), MAE_pct=round(100 * ((q['c'] - lo_) / q['c'] if dd > 0 else (hi_ - q['c']) / q['c']), 4))
                else: f_.update(data_available='FALSE')
                frows.append(f_)
            prog.update({f'r{lv}_close': cl(B, T), f'r{lv}_market': mk, f'r{lv}_price': q['c'], f'r{lv}_OI': q['oc']})
        lrows.append(e)
    def hrs(a, b): return (M['lv'][b] - M['lv'][a]) if a in M['lv'] and b in M['lv'] else ''
    prog.update(hours_80_90=hrs(80, 90), hours_80_100=hrs(80, 100), hours_90_100=hrs(90, 100), hours_100_107=hrs(100, 107), **{f'reached_{lv}': 'TRUE' if lv in M['lv'] else 'FALSE' for lv in LEVELS})
    prows.append(prog)
def wcsv(fn, R, keys=None):
    keys = keys or list(dict.fromkeys(k for r in R for k in r))
    with open(f'{OUT}/{fn}', 'w', newline='') as g:
        w = csv.DictWriter(g, fieldnames=keys, extrasaction='ignore'); w.writeheader()
        for x in R: w.writerow({k: (round(v, 6) if isinstance(v, float) else v) for k, v in x.items()})
MCOLS = ['coin', 'movement_id', 'oi_direction', 'start_UTC_open', 'start_UTC_close', 'start_OI_open', 'start_OI_close', 'start_price_open', 'start_price_close', 'OI0', 'extreme_UTC_open', 'extreme_UTC_close',
         'extreme_OI', 'extreme_price', 'depth_abs', 'depth_pct', 'depth_hours', 'depth_rel_normal', 'depth_quartile', 'depth_status', 'start_status', 'start_confidence', 'X_moves', 'first_found_close',
         'crossing_UTC_open', 'max_return_pct', 'market_structure_start', 'market_structure_end', 'market_direction', 'market_direction_reason', 'structure_lowest', 'structure_highest', 'counter_swing_pct_of_range']
wcsv('movements.csv', mrows, MCOLS); wcsv('level_events.csv', lrows); wcsv('level_followup.csv', frows); wcsv('level_progression.csv', prows)
json.dump(dict(candles=CNT, movements=len(mrows), start_status=C.Counter(r['start_status'] for r in mrows), depth_quartile_cuts=qc), open(f'{OUT}/scan_counts.json', 'w'), indent=1)
print(dict(CNT), len(mrows), C.Counter(r['start_status'] for r in mrows), qc)
