#!/usr/bin/env python3
"""RESEARCH PIPELINE (runs on the server after the read-only data export; Python 3.8+, standard library only).
  python3 research_pipeline.py window <all_1h.csv>          -> prints the export window "<from> <to>" (UTC, [from, to)) for the DB step
  python3 research_pipeline.py run <export_dir> <kit_dir>   -> finder + end rule + liquidation enrichment + hourly details + checks + ZIP
Rules used (unchanged):
  finder      finder/oi_cascade_research_v2.py, byte-identical to the restored hfinder3 file (sha256 checked); only its two path constants are
              replaced in a temporary run copy (input loader directory, output directory) and the copy is verified to differ in exactly those lines.
  end rule    the post-processing used on 2026-10-13 (restored/end_postprocess.py): first close with return > 80 %:
              >= 95 % -> end on that close (IMMEDIATE_95_PLUS, OVER_110 flag above 110 %); otherwise end on exactly ONE next closed candle
              (NEXT_CANDLE_AFTER_80_95); next candle not closed yet -> PENDING.  Never changes S / X / OI0 / id / direction.
  liquidation hourly sums of our DB minute_bars (all_1h.csv long_liq_usd / short_liq_usd, db_minutes = minutes present).
              60 minutes COMPLETE, 1..59 PARTIAL, 0 DATA_MISSING (value left EMPTY, never 0), beyond the data NOT_IN_DATA.
Candles after the observation end are written for later analysis only; they are never used by the finder or the end rule."""
import sys, os, csv, json, hashlib, subprocess, zipfile, io, datetime as dt, collections as C
FINDER_SHA = '308a346402f4e97da349ccf5af66fa59e701960e9cec021e61028ca9f88aecb3'
LOAD_SHA = '8493037dd8367270bcd6c63598a3a9c230d25b9428ac5b48e9ec4b40462caf0c'
COINS = [c + 'USDT' for c in 'ADA ALGO AVAX BCH BNB BTC DOGE DOT ENA ETH HBAR HYPE LINK LTC NEAR ONDO SOL STRK SUI UNI WLD XLM XRP XTZ ZEC'.split()]
NEED = ('open', 'high', 'low', 'close', 'oi_open', 'oi_close')
P = lambda s: dt.datetime.strptime(s, '%Y-%m-%d %H:%M'); F = lambda d: d.strftime('%Y-%m-%d %H:%M'); HR = dt.timedelta(hours=1)
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()

def window(path):
    t = [r['open_time_utc'] for r in csv.DictReader(open(path))]
    print(min(t).replace(' ', 'T'), F(P(max(t)) + HR).replace(' ', 'T'))   # ISO without spaces (read by the shell as two words)

def run(EXP, KIT):
    RAW = os.path.join(EXP, 'raw'); OUT = os.path.join(EXP, 'research'); os.makedirs(OUT, exist_ok=False)
    checks = {}; problems = []
    def ok(name, cond, detail=''):
        checks[name] = {'result': 'PASS' if cond else 'FAIL', 'detail': detail}
        if not cond: problems.append(f'{name}: {detail}')
    # ------------------------------------------------------------ 1. input validation (no repair, no filling)
    rows = list(csv.DictReader(open(os.path.join(RAW, 'all_1h.csv'))))
    hdr = list(rows[0].keys())
    by = C.defaultdict(dict)
    for r in rows: by[r['symbol']][r['open_time_utc']] = r
    ok('25_coins_present', sorted(by) == sorted(COINS), f'found {len(by)}: missing {sorted(set(COINS) - set(by))}')
    allh = sorted({r['open_time_utc'] for r in rows}); grid = [F(P(allh[0]) + i * HR) for i in range(int((P(allh[-1]) - P(allh[0])) / HR) + 1)]
    holes = [(s, h) for s in by for h in grid if h not in by[s]]
    ok('hour_grid_complete', not holes, f'{len(by)} coins x {len(grid)} hours, missing rows {len(holes)} {holes[:5]}')
    bad = sorted({h for s in by for h in grid if h in by[s] and any(by[s][h][k] == '' for k in NEED)})
    trail = []
    while bad and bad[-1] == grid[-1 - len(trail)]: trail.append(bad.pop())               # only TRAILING incomplete hours may be cut
    ok('no_incomplete_hour_inside_window', not bad, f'hours with an empty price/OI field inside the window: {bad[:10]}')
    use = grid[:len(grid) - len(trail)] if trail else grid
    fin = os.path.join(OUT, 'finder_input_1h.csv')
    with open(fin, 'w', newline='') as g:
        w = csv.DictWriter(g, fieldnames=hdr); w.writeheader()
        for s in sorted(by):
            for h in use:
                if h in by[s]: w.writerow(by[s][h])
    win = dict(first_TV_open=use[0], last_TV_open=use[-1], last_UTC_close=F(P(use[-1]) + HR), hours=len(use), trailing_hours_cut_incomplete=sorted(trail))
    if problems:
        return finish(EXP, OUT, KIT, checks, problems, win, {})
    # ------------------------------------------------------------ 2. finder (unchanged code)
    fsrc = os.path.join(KIT, 'finder', 'oi_cascade_research_v2.py'); lsrc = os.path.join(KIT, 'finder', 'load.py')
    ok('finder_file_is_restored_hfinder3', sha(fsrc) == FINDER_SHA, sha(fsrc)); ok('loader_file_unchanged', sha(lsrc) == LOAD_SHA, sha(lsrc))
    orig = open(fsrc).read().split('\n'); A = "sys.path.append('/home/claude/v11/out/sim_src')"; B = "OUT = '/home/claude/v11/out/cyc/hfinder3'"
    def make(run_dir):
        os.makedirs(run_dir)
        new = [l.replace(A, f"sys.path.append({os.path.join(KIT, 'finder')!r})").replace(B, f"OUT = {run_dir!r}") for l in orig]
        diff = [i for i, (a, b) in enumerate(zip(orig, new)) if a != b]
        ok(f'finder_copy_only_paths_changed[{os.path.basename(run_dir)}]', len(diff) == 2 and len(orig) == len(new), f'changed lines {diff}')
        p = os.path.join(run_dir, 'finder_run_copy.py'); open(p, 'w').write('\n'.join(new))
        r = subprocess.run([sys.executable, p, fin], cwd=run_dir, capture_output=True, text=True)
        ok(f'finder_ran[{os.path.basename(run_dir)}]', r.returncode == 0, (r.stderr or r.stdout)[-600:])
        return run_dir
    f1 = make(os.path.join(OUT, 'finder')); f2 = make(os.path.join(OUT, 'finder_rerun_check'))
    for fn in ('movements.csv', 'level_events.csv', 'level_progression.csv', 'level_followup.csv'):
        a, b = os.path.join(f1, fn), os.path.join(f2, fn)
        ok(f'finder_deterministic[{fn}]', os.path.exists(a) and os.path.exists(b) and sha(a) == sha(b), '')
    if problems: return finish(EXP, OUT, KIT, checks, problems, win, {})
    # ------------------------------------------------------------ 3. end rule (post-processing, same logic as 2026-10-13)
    sys.path.insert(0, os.path.join(KIT, 'finder')); from load import load, U, H
    D = load(fin); cl = lambda B, i: U(B[i]['t'] + H)[:16]; tv = lambda B, i: U(B[i]['t'])[:16]
    mtext = open(os.path.join(f1, 'movements.csv'), newline='').read()
    M = list(csv.DictReader(io.StringIO(mtext))); keys = list(M[0].keys())
    E80 = {e['movement_id']: e for e in csv.DictReader(open(os.path.join(f1, 'level_events.csv'))) if e['return_level'] == '80'}
    NEW = ['first_above80_UTC_close', 'first_above80_return_pct', 'market_direction_at_80_level_old', 'end_reason', 'OVER_110', 'end_TV_open', 'end_UTC_close',
           'end_price_open', 'end_price_high', 'end_price_low', 'end_price_close', 'end_OI_open', 'end_OI_close', 'end_return_pct', 'next_candle_reached_95']
    outE = []; END = {}
    for m in M:
        r = dict(m)
        if m['start_status'] == 'FOUND':
            B = D[m['coin'] + 'USDT']; ic = {cl(B, i): i for i in range(len(B))}
            S, X = ic[m['start_UTC_close']], ic[m['extreme_UTC_close']]; mv = 1 if m['oi_direction'] == 'UP' else -1
            OI0, OX = B[S]['oc'], B[X]['oc']
            ret = lambda t: 100 * (B[t]['oc'] - OX) / (OI0 - OX)
            end = None
            for t in range(X + 1, len(B)):
                if mv * (B[t]['oc'] - OX) > 0: break
                q = ret(t)
                if q > 80:
                    r.update(first_above80_UTC_close=cl(B, t), first_above80_return_pct=round(q, 3), market_direction_at_80_level_old=E80.get(m['movement_id'], {}).get('market_direction', ''))
                    if q >= 95: end = (t, 'IMMEDIATE_95_PLUS')
                    elif t + 1 < len(B): end = (t + 1, 'NEXT_CANDLE_AFTER_80_95')
                    else: end = (None, 'PENDING')
                    break
            if end:
                t, why = end; r['end_reason'] = why
                if t is not None:
                    b = B[t]; q = ret(t); END[m['movement_id']] = t
                    r.update(OVER_110='YES' if q > 110 else '', end_TV_open=tv(B, t), end_UTC_close=cl(B, t), end_price_open=b['o'], end_price_high=b['h'], end_price_low=b['l'],
                             end_price_close=b['c'], end_OI_open=b['oo'], end_OI_close=b['oc'], end_return_pct=round(q, 3),
                             next_candle_reached_95=('YES' if q >= 95 else 'NO') if why == 'NEXT_CANDLE_AFTER_80_95' else '')
        outE.append(r)
    pE = os.path.join(OUT, 'movements_with_end.csv')
    with open(pE, 'w', newline='') as g:
        w = csv.DictWriter(g, fieldnames=keys + NEW); w.writeheader(); [w.writerow(x) for x in outE]
    # ------------------------------------------------------------ 4. liquidation per hour (raw all_1h, incl. trailing hours, analysis only)
    LQ = {}
    for r in rows:
        n = int(r['db_minutes'] or 0)
        st = 'COMPLETE' if n == 60 else 'DATA_MISSING' if n == 0 else 'PARTIAL'
        LQ[(r['symbol'], r['open_time_utc'])] = dict(n=n, st=st, L=None if st == 'DATA_MISSING' else float(r['long_liq_usd']), S=None if st == 'DATA_MISSING' else float(r['short_liq_usd']), r=r)
    last_raw = grid[-1]
    def seg(sym, hs):
        if hs is None: return {'status': 'NOT_APPLICABLE'}
        if not hs or hs[-1] > last_raw: return {'status': 'NOT_IN_DATA'}
        q = [LQ[(sym, h)] for h in hs]; mins = sum(x['n'] for x in q); have = [x for x in q if x['st'] != 'DATA_MISSING']
        d = {'utc_from': hs[0], 'utc_to': F(P(hs[-1]) + HR), 'hours': len(hs), 'coverage_minutes': f'{mins}/{60 * len(hs)}'}
        if not have: d['status'] = 'DATA_MISSING'; return d
        L = sum(x['L'] for x in have); S_ = sum(x['S'] for x in have)
        d.update(status='COMPLETE' if mins == 60 * len(hs) else 'PARTIAL', long_liq_usd=round(L, 2), short_liq_usd=round(S_, 2), total_liq_usd=round(L + S_, 2),
                 long_short_ratio=round(L / S_, 4) if S_ > 0 else '', long_share=round(L / (L + S_), 4) if L + S_ > 0 else '')
        return d
    SEG = ['A_S_to_X', 'B_X_to_end', 'C_end_candle'] + [f'D_after_end_{k}' for k in (1, 2, 3, 4)] + [f'E_before_end_{k}' for k in (1, 2, 3, 4)]
    SF = ('status', 'utc_from', 'utc_to', 'hours', 'coverage_minutes', 'long_liq_usd', 'short_liq_usd', 'total_liq_usd', 'long_short_ratio', 'long_share')
    etext = open(pE, newline='').read(); er = list(csv.reader(io.StringIO(etext))); eh = er[0]
    rng = lambda a, b: [F(P(a) + i * HR) for i in range(int((P(b) - P(a)) / HR) + 1)]
    outL = []
    for row in er[1:]:
        m = dict(zip(eh, row)); sym = m['coin'] + 'USDT'
        tv_ = lambda close, k=0: F(P(close) - HR + k * HR)                 # TV open of the candle whose UTC close is `close`, shifted by k candles
        S = m['start_UTC_close'] if m['start_status'] == 'FOUND' else None; X = m['extreme_UTC_close']; E = m.get('end_UTC_close') or None
        s = {'A_S_to_X': seg(sym, rng(tv_(S, 1), tv_(X)) if S else None),
             'B_X_to_end': seg(sym, rng(tv_(X, 1), tv_(E)) if E else None), 'C_end_candle': seg(sym, [tv_(E)] if E else None)}
        for k in (1, 2, 3, 4):
            s[f'D_after_end_{k}'] = seg(sym, [tv_(E, k)] if E else None); s[f'E_before_end_{k}'] = seg(sym, [tv_(E, -k)] if E and P(tv_(E, -k)) >= P(grid[0]) else None)
        outL.append(row + [str(s[x].get(f, '')) for x in SEG for f in SF])
    pL = os.path.join(OUT, 'movements_with_liquidations.csv')
    with open(pL, 'w', newline='') as g:
        w = csv.writer(g); w.writerow(eh + [f'liq_{x}_{f}' for x in SEG for f in SF]); [w.writerow(x) for x in outL]
    # ------------------------------------------------------------ 5. hourly details (before / during / after)
    DET = ['movement_id', 'coin', 'oi_direction', 'market_direction', 'end_reason', 'phase', 'hours_from_X', 'after_observation_end', 'TV_open', 'UTC_close',
           'price_open', 'price_high', 'price_low', 'price_close', 'oi_open', 'oi_close', 'db_oi_close', 'oi_return_pct', 'long_liq_usd', 'short_liq_usd', 'total_liq_usd',
           'coverage_minutes', 'liq_data_status']
    with open(os.path.join(OUT, 'cascade_hourly_details.csv'), 'w', newline='') as g:
        w = csv.DictWriter(g, fieldnames=DET); w.writeheader()
        for m in outE:
            if m['start_status'] != 'FOUND': continue
            sym = m['coin'] + 'USDT'; S = P(m['start_UTC_close']) - HR; X = P(m['extreme_UTC_close']) - HR
            E = P(m['end_UTC_close']) - HR if m.get('end_UTC_close') else None
            OI0, OX = float(m['OI0']), float(m['extreme_OI'])
            t = S - 4 * HR; stop = (E or X) + 4 * HR
            while t <= stop:
                h = F(t); q = LQ.get((sym, h))
                if q is None: t += HR; continue
                r = q['r']
                if t < S: ph = f'PRE_S_{int((S - t) / HR)}'
                elif t == S: ph = 'S'
                elif t < X: ph = 'BUILD_S_TO_X'
                elif t == X: ph = 'X'
                elif E is None: ph = 'AFTER_X_NO_END'
                elif t < E: ph = 'RETURN_X_TO_END'
                elif t == E: ph = 'END'
                else: ph = f'POST_END_{int((t - E) / HR)}'
                oc = float(r['oi_close']) if r['oi_close'] else None
                w.writerow(dict(movement_id=m['movement_id'], coin=m['coin'], oi_direction=m['oi_direction'], market_direction=m['market_direction'], end_reason=m.get('end_reason', ''),
                                phase=ph, hours_from_X=int((t - X) / HR), after_observation_end='YES' if E is not None and t > E else '', TV_open=h, UTC_close=F(t + HR),
                                price_open=r['open'], price_high=r['high'], price_low=r['low'], price_close=r['close'], oi_open=r['oi_open'], oi_close=r['oi_close'], db_oi_close=r['db_oi_close'],
                                oi_return_pct=round(100 * (oc - OX) / (OI0 - OX), 3) if oc is not None and OI0 != OX else '',
                                long_liq_usd='' if q['L'] is None else round(q['L'], 2), short_liq_usd='' if q['S'] is None else round(q['S'], 2),
                                total_liq_usd='' if q['L'] is None else round(q['L'] + q['S'], 2), coverage_minutes=f'{q["n"]}/60', liq_data_status=q['st']))
                t += HR
    # ------------------------------------------------------------ 6. coverage (every coin-hour) + raw event counts (separate source, not merged)
    EVC = C.Counter()
    pev = os.path.join(RAW, 'liq_events.csv')
    if os.path.exists(pev):
        for e in csv.DictReader(open(pev)): EVC[(e['symbol'], e['time_utc'][:14] + '00')] += 1
    MB = C.defaultdict(lambda: [0, 0.0, 0.0]); pmb = os.path.join(RAW, 'minute_bars.csv')
    if os.path.exists(pmb):
        for b in csv.DictReader(open(pmb)):
            k = (b['symbol'], b['minute_utc'][:14] + '00'); MB[k][0] += 1; MB[k][1] += float(b['longLiqUsd'] or 0); MB[k][2] += float(b['shortLiqUsd'] or 0)
    with open(os.path.join(OUT, 'liquidation_coverage.csv'), 'w', newline='') as g:
        w = csv.writer(g); w.writerow(['symbol', 'open_time_utc', 'db_minutes', 'liq_data_status', 'long_liq_usd', 'short_liq_usd', 'raw_liq_events_in_hour', 'minute_bars_rows_in_export'])
        for (s, h), q in sorted(LQ.items()):
            w.writerow([s, h, q['n'], q['st'], '' if q['L'] is None else q['r']['long_liq_usd'], '' if q['S'] is None else q['r']['short_liq_usd'], EVC.get((s, h), 0), MB[(s, h)][0] if os.path.exists(pmb) else ''])
    cov = C.Counter(q['st'] for q in LQ.values())
    # ------------------------------------------------------------ 7. invariance + consistency checks
    def prefix_same(a_text, b_text):
        A_ = list(csv.reader(io.StringIO(a_text))); B_ = list(csv.reader(io.StringIO(b_text))); k = len(A_[0])
        return len(A_) == len(B_) and all(x == y[:k] for x, y in zip(A_, B_))
    ok('movements_unchanged_in_with_end', prefix_same(mtext, etext), 'all finder columns / rows byte-equal')
    ok('with_end_unchanged_in_with_liquidations', prefix_same(etext, open(pL, newline='').read()), 'all previous columns / rows byte-equal')
    K = ('movement_id', 'start_UTC_close', 'extreme_UTC_close', 'OI0', 'market_direction', 'end_UTC_close', 'end_return_pct')
    E_ = list(csv.DictReader(open(pE))); L_ = list(csv.DictReader(open(pL)))
    ok('key_fields_before_after_enrichment', len(E_) == len(L_) and all(all(a.get(k, '') == b.get(k, '') for k in K) for a, b in zip(E_, L_)), ', '.join(K))
    ok('no_zero_filled_missing_hours', all((q['L'] is None) == (q['st'] == 'DATA_MISSING') for q in LQ.values()), '')
    if os.path.exists(pmb):
        mism = [k for k, q in LQ.items() if q['n'] != MB[k][0] or (q['st'] != 'DATA_MISSING' and (abs(MB[k][1] - q['L']) > 0.05 or abs(MB[k][2] - q['S']) > 0.05))]
        ok('minute_bars_dump_matches_hourly_sums', not mism, f'mismatching coin-hours {len(mism)} {mism[:5]}')
    btcb = [m for m in outE if m['coin'] == 'BTC' and m['extreme_UTC_close'] == '2026-10-04 23:00' and m['oi_direction'] == 'DOWN']
    info = {'BTC_B_reference': ('not in this window' if not btcb else f'S {btcb[0]["start_UTC_close"]} OI0 {btcb[0]["OI0"]} (reference 2026-10-04 21:00 / 98574.734: '
                                + ('MATCH' if btcb[0]['start_UTC_close'] == '2026-10-04 21:00' and abs(float(btcb[0]['OI0']) - 98574.734) < 0.01 else 'DIFFERENT - window changed or check') + ')')}
    stats = dict(movements=len(outE), found=sum(m['start_status'] == 'FOUND' for m in outE), end_reasons=dict(C.Counter(m.get('end_reason', '') or 'no close above 80 %' for m in outE if m['start_status'] == 'FOUND')),
                 liquidation_coin_hours=dict(cov), **info)
    return finish(EXP, OUT, KIT, checks, problems, win, stats)

def finish(EXP, OUT, KIT, checks, problems, win, stats):
    RAW = os.path.join(EXP, 'raw')
    inv = json.load(open(os.path.join(RAW, 'db_inventory.json'))) if os.path.exists(os.path.join(RAW, 'db_inventory.json')) else None
    proj = os.environ.get('PROJECT_DIR', '')
    git = ''
    try: git = subprocess.run(['git', '-C', proj, 'rev-parse', 'HEAD'], capture_output=True, text=True).stdout.strip()
    except Exception: pass
    code = {os.path.relpath(p, KIT): sha(p) for p in [os.path.join(KIT, f) for f in ('research_pipeline.py', 'research-db-extra.cjs', 'run_research_export.sh', 'finder/oi_cascade_research_v2.py', 'finder/load.py')] if os.path.exists(p)}
    exp_ts = os.path.join(proj, 'src', 'tools', 'research-1h-export.ts')
    if os.path.exists(exp_ts): code['project:src/tools/research-1h-export.ts'] = sha(exp_ts)
    readme = open(os.path.join(RAW, 'README.txt')).read() if os.path.exists(os.path.join(RAW, 'README.txt')) else ''
    man = dict(run_utc=dt.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'), status='OK' if not problems else 'FAILED', problems=problems, window=win,
               sources={'price': 'Binance USDT-M 1h klines (/fapi/v1/klines) via src/tools/research-1h-export.ts (unchanged)',
                        'oi': 'Binance /futures/data/openInterestHist 5m (oi_open = OI at hour start, oi_close = at hour end; Binance keeps ~30 days) via the same script',
                        'db': 'our MongoDB, read-only: minute_bars (OI + liquidation sums per minute), liq_raw_events (every liquidation, kept ~14 days), oi_second_observations (inventory only)',
                        'export_script_readme': readme.strip(), 'db_inventory': inv},
               code_sha256=code, project_git_commit=git, checks=checks, results=stats,
               notes=['LONG = longs liquidated (forced sells), SHORT = shorts liquidated (forced buys).',
                      'DATA_MISSING hours have EMPTY liquidation values (not zero). PARTIAL = some minutes missing; sums cover only the minutes present.',
                      'Rows with after_observation_end = YES are for later analysis only; the finder and the end rule never use them.',
                      'This window is not compared to the 2026-10-12 export as an identity test: the data window is different.'])
    json.dump(man, open(os.path.join(OUT, 'export_manifest.json'), 'w'), indent=1)
    # ZIP: the 7 requested files at the root, raw exports and code in folders
    z = EXP.rstrip('/') + '.zip'
    with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as Z:
        top = {'all_1h.csv': os.path.join(RAW, 'all_1h.csv'), 'movements.csv': os.path.join(OUT, 'finder', 'movements.csv'), 'movements_with_end.csv': os.path.join(OUT, 'movements_with_end.csv'),
               'movements_with_liquidations.csv': os.path.join(OUT, 'movements_with_liquidations.csv'), 'cascade_hourly_details.csv': os.path.join(OUT, 'cascade_hourly_details.csv'),
               'liquidation_coverage.csv': os.path.join(OUT, 'liquidation_coverage.csv'), 'export_manifest.json': os.path.join(OUT, 'export_manifest.json')}
        for a, p in top.items():
            if os.path.exists(p): Z.write(p, a)
        for fn in ('level_events.csv', 'level_progression.csv', 'level_followup.csv', 'scan_counts.json'):
            p = os.path.join(OUT, 'finder', fn)
            if os.path.exists(p): Z.write(p, 'finder/' + fn)
        for fn in ('liq_events.csv', 'minute_bars.csv', 'db_inventory.json', 'README.txt'):
            p = os.path.join(RAW, fn)
            if os.path.exists(p): Z.write(p, 'raw/' + fn)
        Z.write(os.path.join(OUT, 'finder_input_1h.csv'), 'finder/finder_input_1h.csv') if os.path.exists(os.path.join(OUT, 'finder_input_1h.csv')) else None
        for f in code:
            if not f.startswith('project:'): Z.write(os.path.join(KIT, f), 'code/' + f)
        if os.path.exists(exp_ts): Z.write(exp_ts, 'code/project_src_tools_research-1h-export.ts')
    print(json.dumps({'status': man['status'], 'problems': problems, 'window': win, 'results': stats}, indent=1))
    print('ZIP=' + z)
    return 0 if not problems else 1

if __name__ == '__main__':
    if sys.argv[1] == 'window': window(sys.argv[2])
    elif sys.argv[1] == 'run': sys.exit(run(os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])))
